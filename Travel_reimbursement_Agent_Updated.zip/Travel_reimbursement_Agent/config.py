"""
Centralized application configuration.

Loaded once via `get_settings()` (lru_cache'd singleton) so every module that
needs a config value gets the exact same instance without re-parsing the
environment or `.env` file. Values can be overridden via environment
variables or a `.env` file at the project root (see `.env.example`).
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=True,
    )

    # ── API metadata ─────────────────────────────────────────────────────
    API_TITLE: str = "Travel Reimbursement Approval Agent"
    API_VERSION: str = "1.0.0"
    ENVIRONMENT: str = "development"  # development | staging | production

    # ── Groq / LLM ───────────────────────────────────────────────────────
    GROQ_API_KEY: str = ""
    GROQ_MODEL: str = "openai/gpt-oss-120b"
    GROQ_TEMPERATURE: float = 0.1
    GROQ_MAX_RETRIES: int = 2

    # Validator tolerance: how far the LLM's proposed approved_amount/deduction
    # may drift from the deterministically computed value before being
    # silently overridden.
    LLM_AMOUNT_MISMATCH_TOLERANCE: float = 1.0

    # Below this LLM self-reported confidence, force manual_review=True.
    MIN_CONFIDENCE_FOR_AUTO_DECISION: float = 0.6

    # ── Embeddings / RAG ─────────────────────────────────────────────────
    EMBEDDING_MODEL: str = "BAAI/bge-small-en-v1.5"
    EMBEDDING_DEVICE: str = "cpu"

    CHUNK_SIZE: int = 800
    CHUNK_OVERLAP: int = 120

    RETRIEVAL_TOP_K: int = 4
    # Relevance scores from similarity_search_with_relevance_scores are
    # normalized roughly into [0, 1] (higher = more relevant).
    RETRIEVAL_MIN_RELEVANCE_SCORE: float = 0.35

    # ── Paths ────────────────────────────────────────────────────────────
    DATA_DIR: Path = BASE_DIR / "data"
    OUTPUT_DIR: Path = BASE_DIR / "output"
    LOGS_DIR: Path = BASE_DIR / "logs"

    POLICY_MD_PATH: Path = BASE_DIR / "data" / "travel_policy.md"
    APPROVAL_MATRIX_PATH: Path = BASE_DIR / "data" / "approval_matrix.json"
    LIMITS_PATH: Path = BASE_DIR / "data" / "limits.json"
    SAMPLE_CLAIMS_PATH: Path = BASE_DIR / "data" / "sample_claims.json"

    FAISS_INDEX_DIR: Path = BASE_DIR / "output" / "faiss_index"
    CLAIMS_LEDGER_PATH: Path = BASE_DIR / "output" / "claims_ledger.json"

    LOG_LEVEL: str = "INFO"
    LOG_FILE: Path = BASE_DIR / "logs" / "app.log"
    DECISION_LOG_FILE: Path = BASE_DIR / "logs" / "decisions.log"


@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    # Ensure runtime directories exist so file handlers / FAISS writes never
    # fail with FileNotFoundError on a fresh checkout or fresh container.
    for d in (settings.DATA_DIR, settings.OUTPUT_DIR, settings.LOGS_DIR, settings.FAISS_INDEX_DIR):
        d.mkdir(parents=True, exist_ok=True)
    return settings
