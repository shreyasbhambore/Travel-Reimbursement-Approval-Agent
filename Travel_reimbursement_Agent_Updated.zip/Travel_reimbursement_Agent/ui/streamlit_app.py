import streamlit as st
import requests

API_URL = "http://127.0.0.1:8000/evaluate-claim"

st.set_page_config(
    page_title="Travel Reimbursement Approval Agent",
    page_icon="✈️",
    layout="wide"
)

st.title("✈️ Travel Reimbursement Approval Agent")
st.write("AI-powered travel claim evaluation using LangGraph + RAG + Groq")

col1, col2 = st.columns(2)

with col1:
    employee_id = st.text_input("Employee ID", "EMP001")
    name = st.text_input("Employee Name", "John Doe")

    trip_type = st.selectbox(
        "Trip Type",
        ["Domestic", "International"]
    )

    receipt_uploaded = st.checkbox(
        "Receipt Uploaded",
        value=True
    )

with col2:
    hotel = st.number_input("Hotel Expense", value=6200)
    flight = st.number_input("Flight Expense", value=14000)
    meal = st.number_input("Meal Expense", value=900)
    taxi = st.number_input("Taxi Expense", value=800)

if st.button("Evaluate Claim", type="primary"):

    payload = {
        "employee_id": employee_id,
        "name": name,
        "trip_type": trip_type,
        "hotel": hotel,
        "flight": flight,
        "meal": meal,
        "taxi": taxi,
        "receipt_uploaded": receipt_uploaded
    }

    with st.spinner("Evaluating claim..."):

        response = requests.post(API_URL, json=payload)

    if response.status_code == 200:

        data = response.json()

        st.success("Evaluation Completed")

        st.subheader("Decision")

        st.metric(
            "Decision",
            data["decision"]
        )

        c1, c2, c3 = st.columns(3)

        c1.metric(
            "Approved Amount",
            f"₹{data['approved_amount']}"
        )

        c2.metric(
            "Deduction",
            f"₹{data['deduction']}"
        )

        c3.metric(
            "Confidence",
            data["confidence"]
        )

        st.write("### Reason")
        st.info(data["reason"])

        st.write("### Policy Reference")
        st.code(data["policy_reference"])

        st.write("### Audit Trail")

        for item in data["audit_trail"]:
            st.write("✅", item)

        if data["validation_issues"]:
            st.write("### Validation Issues")
            st.json(data["validation_issues"])

        st.write("### Complete JSON Response")
        st.json(data)

    else:
        st.error(response.text)