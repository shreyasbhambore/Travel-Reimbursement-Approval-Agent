# Travel Reimbursement Approval Agent

Aa production-grade agentic pipeline that
evaluates employee travel reimbursement claims against a corporate travel
policy using **LangGraph**, **RAG** (FAISS + `BAAI/bge-small-en-v1.5`), and
**Groq**'s LLM (`llama-3.3-70b-versatile` by default), exposed via **FastAPI**.

Given a claim like:

```json
{
  "employee_id": "EMP001",
  "name": "John Doe",
  "trip_type": "Domestic",
  "hotel": 6200,
  "flight": 14000,
  "meal": 900,
  "taxi": 800,
  "receipt_uploaded": true
}
```

the agent retrieves the relevant policy clauses, runs six deterministic
checks, asks the LLM for a decision narrative, arithmetically validates that
narrative against ground truth, and returns a structured decision:

```json
{
  "decision": "Partially Approved",
  "approved_amount": 20700.0,
  "deduction": 1200.0,
  "manual_review": false,
  "policy_reference": "Section 3: Hotel cap ₹5,000/night for Domestic trips.",
  "reason": "Hotel expense exceeded the domestic cap; ₹1,200 deducted.",
  "audit_trail": [
    "Retrieved policy",
    "Validated receipts",
    "Applied limits",
    "Checked duplicates",
    "Generated decision"
  ]
}
```

---

## 1. Architecture

```
                         ┌─────────────────────────┐
   POST /evaluate-claim  │        FastAPI            │  GET /health
   ────────────────────► │        (app.py)           │ ─────────────►
                         └───────────┬───────────────┘
                                     │ initial_state(claim)
                                     ▼
                     ┌───────────────────────────────────┐
                     │        LangGraph StateGraph        │
                     │           (agent/graph.py)          │
                     │                                     │
   START ──► claim_intake ──► retrieve_policy ──► receipt_validation
                     │                                     │
                     ▼                                     ▼
             expense_limit ──► approval_matrix ──► duplicate_check
                     │
                     ▼
             llm_decision (Groq LLM, structured output)
                     │
                     ▼
             output_validation (arithmetic guard + manual_review rules)
                     │
                     ▼
                    END ──► final_decision: ClaimDecision
                     └───────────────────────────────────┘
```

Every node is a pure function `AgentState -> partial dict`, wired to its
dependencies via `agent/nodes.py::build_nodes()` at application startup
(dependency injection — no module-level globals, fully unit-testable).

### The six tools

| # | Tool | File | Purpose |
|---|------|------|---------|
| 1 | Policy Lookup | `tools/policy_lookup.py` | RAG query against the FAISS index of `data/travel_policy.md` |
| 2 | Receipt Checker | `tools/receipt_checker.py` | Verifies required documents are present |
| 3 | Expense Limit Checker | `tools/limit_checker.py` | Applies per-category caps from `data/limits.json`, computes exact deductions |
| 4 | Approval Matrix Checker | `tools/approval_checker.py` | Routes to Auto / Manager / Finance Head per `data/approval_matrix.json` |
| 5 | Duplicate Checker | `tools/duplicate_checker.py` | 3-tier duplicate detection against `ledger.py` |
| 6 | Output Validator | `tools/validator.py` | Arithmetic guard + `manual_review` rule enforcement + final schema assembly |

Each tool exposes both a plain `.run(...)` method (used by the deterministic
graph nodes) **and** `.as_langchain_tool()` (a `StructuredTool` — proof these
are real, bindable LangChain tools, not just plain functions).

### Design decision: `manual_review` vs. `approval_level`

These are deliberately two independent signals:

- **`approval_level`** (`Auto` / `Manager` / `FinanceHead`) — *who* must sign
  off for disbursement, based purely on claimed amount (and flight-class
  violations).
- **`manual_review`** (`true`/`false`) — whether the **AI's own reasoning**
  should be double-checked by a human before that signer trusts it (missing
  docs, suspected duplicate, unknown category, low retrieval confidence, or
  low LLM confidence).

A ₹3,000 claim can still be `manual_review: true` if its receipt is missing;
a ₹60,000 clean claim is `manual_review: false` but still requires Finance
Head sign-off. See `tools/approval_checker.py` and `tools/validator.py`
docstrings for the full rationale.

### Design decision: monetary arithmetic is never LLM-authoritative

`tools/limit_checker.py` computes the exact deduction/approved amount
deterministically from `data/limits.json`. The LLM is asked to *propose* the
same figures as part of its decision narrative, but `tools/validator.py`
always cross-checks the LLM's numbers against the deterministic calculation
and silently overrides them (logging a `ValidationIssue`) if they drift by
more than `LLM_AMOUNT_MISMATCH_TOLERANCE`. This means the API's financial
figures are reproducible and auditable even though the *narrative* comes
from a non-deterministic LLM call.

---

## 2. Folder Structure

```
travel-reimbursement-agent/
├── app.py                     # FastAPI app: /health, /evaluate-claim, lifespan startup
├── config.py                  # Settings (pydantic-settings), loads .env
├── schemas.py                 # Every Pydantic model used across the app
├── ledger.py                  # File-backed claims ledger (duplicate detection store)
├── logging_config.py          # Logging setup (console + logs/app.log + logs/decisions.log)
│
├── agent/                     # LangGraph workflow
│   ├── __init__.py
│   ├── state.py                # AgentState TypedDict + initial_state()
│   ├── prompts.py               # System + decision prompt templates
│   ├── nodes.py                  # Node implementations + build_nodes() factory
│   └── graph.py                   # StateGraph construction (build_graph())
│
├── rag/                        # Retrieval-Augmented Generation
│   ├── __init__.py
│   ├── ingest.py                # Chunk travel_policy.md, embed, build/persist FAISS
│   ├── vector_store.py           # FAISS + BAAI/bge-small-en-v1.5 wrapper
│   └── retriever.py               # Query interface -> PolicyRetrievalResult
│
├── tools/                      # The six LangChain tools
│   ├── __init__.py
│   ├── policy_lookup.py
│   ├── receipt_checker.py
│   ├── limit_checker.py
│   ├── approval_checker.py
│   ├── duplicate_checker.py
│   └── validator.py
│
├── data/                       # Static policy & configuration data
│   ├── travel_policy.md          # Source document for RAG ingestion
│   ├── limits.json                # Per-category expense caps
│   ├── approval_matrix.json        # Amount-based approval routing tiers
│   └── sample_claims.json           # Example requests covering all 4 decision labels
│
├── output/                     # Runtime-generated artifacts (git-ignored)
│   └── faiss_index/               # Persisted FAISS index (built on first run)
│   └── claims_ledger.json          # Persisted claim history
│
├── logs/                       # Runtime logs (git-ignored)
│   ├── app.log                    # Rotating application log
│   └── decisions.log               # JSON-lines decision audit trail
│
├── tests/
│   ├── __init__.py
│   ├── conftest.py                # Shared fixtures (mock claims, mock retriever)
│   ├── test_tools.py               # Unit tests for all 6 tools
│   └── test_api.py                  # FastAPI endpoint tests (mocked graph)
│
├── requirements.txt
├── Dockerfile
├── pytest.ini
├── .env.example
├── .gitignore
└── README.md
```

---

## 3. Installation

```bash
# 1. Clone / unzip the project, then:
cd travel-reimbursement-agent

# 2. Create a virtual environment
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment variables
cp .env.example .env
# then edit .env and set GROQ_API_KEY (get one free at https://console.groq.com/keys)

# 5. Build the FAISS index (optional -- app.py builds it automatically on
#    first startup if it doesn't exist yet)
python -m rag.ingest

# 6. Run the API
uvicorn app:app --reload
```

Visit **http://localhost:8000/docs** for interactive Swagger UI.

---

## 4. Environment Variables

All variables live in `.env` (see `.env.example`); every one has a sane
default in `config.py` except `GROQ_API_KEY`.

| Variable | Default | Description |
|---|---|---|
| `GROQ_API_KEY` | *(empty)* | **Required** for live LLM decisions. Without it the API still starts but `/evaluate-claim` returns `503`. |
| `GROQ_MODEL` | `openai/gpt-oss-120b` | Groq model id |
| `GROQ_TEMPERATURE` | `0.1` | Sampling temperature for the decision LLM |
| `GROQ_MAX_RETRIES` | `2` | Retries on LLM call failure before falling back to a safe `Manual Review` |
| `LLM_AMOUNT_MISMATCH_TOLERANCE` | `1.0` | ₹ tolerance before the validator overrides the LLM's proposed amounts |
| `MIN_CONFIDENCE_FOR_AUTO_DECISION` | `0.6` | Below this LLM confidence, force `manual_review=true` |
| `EMBEDDING_MODEL` | `BAAI/bge-small-en-v1.5` | HuggingFace embedding model for FAISS |
| `EMBEDDING_DEVICE` | `cpu` | `cpu` or `cuda` |
| `CHUNK_SIZE` / `CHUNK_OVERLAP` | `800` / `120` | Markdown chunking parameters |
| `RETRIEVAL_TOP_K` | `4` | Chunks returned per policy query |
| `RETRIEVAL_MIN_RELEVANCE_SCORE` | `0.35` | Below this, `low_confidence=true` -> forces manual review |
| `API_TITLE` / `API_VERSION` / `ENVIRONMENT` | see `.env.example` | Metadata surfaced in `/health` and Swagger |
| `LOG_LEVEL` | `INFO` | Logging verbosity |

---

## 5. FastAPI Endpoints

### `GET /health`

Returns service health without requiring authentication — safe for
container/load-balancer probes.

```json
{
  "status": "ok",
  "version": "1.0.0",
  "groq_configured": true,
  "vector_store_ready": true,
  "details": {
    "groq_model": "openai/gpt-oss-120b",
    "environment": "development",
    "embedding_model": "BAAI/bge-small-en-v1.5"
  }
}
```

`status` is `"degraded"` if either the Groq API key is missing or the FAISS
vector store failed to build/load — `/evaluate-claim` will return `503` in
that state instead of a wrong or empty decision.

### `POST /evaluate-claim`

Accepts a `TravelClaim` (see §7 for the schema/examples) and runs it through
the full LangGraph pipeline, returning a `ClaimDecision`.

---

## 6. Swagger / OpenAPI

- Swagger UI: **`/docs`**
- ReDoc: **`/redoc`**
- Raw OpenAPI schema: **`/openapi.json`**

Both endpoints are fully documented with request/response examples pulled
directly from the Pydantic model `json_schema_extra` in `schemas.py`.

---

## 7. Docker

```bash
# Build
docker build -t travel-reimbursement-agent .

# Run (pass your Groq key at runtime; never bake secrets into the image)
docker run -p 8000:8000 \
  -e GROQ_API_KEY=your_groq_api_key_here \
  travel-reimbursement-agent
```

The image pre-builds the FAISS index at build time (`RUN python -m
rag.ingest`) for a fast cold start; if that step is skipped or fails (e.g. no
network during `docker build`), `app.py` builds it lazily on first container
startup instead, and the service reports `degraded` in `/health` in the
meantime rather than crashing.

A `HEALTHCHECK` is wired to `GET /health` so `docker ps` and orchestrators
can see readiness directly.

---

## 8. Testing

```bash
pytest
```

- **`tests/test_tools.py`** — unit tests for all six tools, 100%
  deterministic (no LLM call, no FAISS index needed). Covers the assignment's
  exact example (₹6,200 hotel → ₹1,200 deduction), cap enforcement per
  category, flight-class violations, unknown-category detection, all three
  duplicate-detection strategies, and every validator override rule.
- **`tests/test_api.py`** — FastAPI endpoint tests via `TestClient`, with the
  LangGraph graph replaced by a lightweight mock so tests never require a
  live `GROQ_API_KEY` or a built FAISS index. Covers `/health`, the full
  `/evaluate-claim` happy path, `422` validation errors, `503`
  service-unavailable handling, and Swagger/OpenAPI accessibility.

Both files run without any ML dependency (no `torch`/`faiss`/
`sentence-transformers` needed) — they exercise business logic and API
contracts, not the embedding pipeline. To smoke-test the *real* RAG pipeline
end-to-end, run the app itself (`uvicorn app:app`) with a valid `.env` and
call `/evaluate-claim` for real.

---

## 9. Sample Requests & Responses

`data/sample_claims.json` contains ready-to-POST examples for all four
decision labels. Summarized:

### Approved (auto)
```bash
curl -X POST http://localhost:8000/evaluate-claim -H "Content-Type: application/json" -d '{
  "employee_id": "EMP002", "name": "Asha Mehta", "trip_type": "Domestic",
  "hotel": 3000, "flight": 4000, "meal": 600, "taxi": 500,
  "receipt_uploaded": true, "invoice_number": "INV-2026-0021"
}'
```
→ `decision: "Approved"`, `approval_level: "Auto"`, `deduction: 0.0`

### Partially Approved (assignment brief example)
```bash
curl -X POST http://localhost:8000/evaluate-claim -H "Content-Type: application/json" -d '{
  "employee_id": "EMP001", "name": "John Doe", "trip_type": "Domestic",
  "hotel": 6200, "flight": 14000, "meal": 900, "taxi": 800,
  "receipt_uploaded": true
}'
```
→
```json
{
  "decision": "Partially Approved",
  "approved_amount": 20700.0,
  "deduction": 1200.0,
  "manual_review": false,
  "policy_reference": "Section 3: Hotel cap ₹5,000/night for Domestic trips.",
  "approval_level": "Manager",
  "approver_role": "Direct Manager",
  "audit_trail": ["Retrieved policy", "Validated receipts", "Applied limits", "Checked duplicates", "Generated decision"]
}
```

### Manual Review (Business class without pre-approval)
```bash
curl -X POST http://localhost:8000/evaluate-claim -H "Content-Type: application/json" -d '{
  "employee_id": "EMP005", "name": "Priya Nair", "trip_type": "International",
  "hotel": 9000, "flight": 85000, "meal": 2000, "taxi": 2500,
  "receipt_uploaded": true, "flight_class": "Business", "flight_class_pre_approved": false
}'
```
→ `decision: "Manual Review"`, `manual_review: true`, `approval_level: "FinanceHead"`

### Rejected (no receipt, non-business expense)
```bash
curl -X POST http://localhost:8000/evaluate-claim -H "Content-Type: application/json" -d '{
  "employee_id": "EMP004", "name": "Karan Shah", "trip_type": "Domestic",
  "hotel": 0, "flight": 0, "meal": 0, "taxi": 1500, "receipt_uploaded": false
}'
```
→ `decision: "Rejected"`, `manual_review: true`

See `data/sample_claims.json` for the full set including duplicate-detection
and unknown-category examples.

---

## 10. Future Improvements

- **Real database for the ledger** — swap `ledger.py`'s JSON file for
  Postgres/SQLite behind the same interface; the tool layer doesn't need to
  change.
- **Nights/days-aware claims** — the assignment's payload carries aggregate
  amounts only; accepting explicit `nights`/`days` counts would let
  `limit_checker.py` cap per-night/per-day precisely instead of treating the
  aggregate as a single period.
- **Streaming decisions** — stream the LLM's reasoning tokens to the client
  via SSE for a more responsive UX on larger claims.
- **Multi-currency support** — accept non-INR claims with an FX-rate lookup
  tool rather than assuming INR throughout.
- **ChromaDB fallback** — for ARM platforms where `faiss-cpu` doesn't have a
  prebuilt wheel, swap in ChromaDB behind the same `PolicyVectorStore`
  interface.
- **Human-in-the-loop UI** — a lightweight review queue for claims flagged
  `manual_review: true`, showing the full audit trail and allowing a
  Manager/Finance Head to approve, adjust, or reject with one click.
- **Fine-grained RBAC** — authenticate the `/evaluate-claim` caller and
  restrict which `employee_id`s they may submit claims for.
## Streamlit UI

Run in a separate terminal:

```bash
streamlit run ui/streamlit_app.py
```

Open:

http://localhost:8501