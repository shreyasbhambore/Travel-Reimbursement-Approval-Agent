"""
Unit tests for all tool implementations.

These tests are 100% deterministic -- no LLM is called and no FAISS index is
loaded. They test the business logic of each tool in complete isolation by
constructing inputs from scratch and asserting on the exact outputs.
"""
from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from schemas import FlightClass, TravelClaim, TripType
from tests.conftest import MockRetriever, make_claim


# ── ReceiptCheckerTool ────────────────────────────────────────────────────────

class TestReceiptChecker:
    @pytest.fixture(autouse=True)
    def tool(self):
        from tools.receipt_checker import ReceiptCheckerTool
        self.tool = ReceiptCheckerTool()

    def test_passes_when_receipt_uploaded(self, assignment_claim):
        result = self.tool.run(assignment_claim)
        assert result.passed is True
        assert result.missing_documents == []

    def test_fails_when_receipt_missing(self, missing_receipt_claim):
        result = self.tool.run(missing_receipt_claim)
        assert result.passed is False
        assert "receipt" in result.missing_documents

    def test_fails_when_hotel_invoice_explicitly_false(self):
        claim = make_claim({"hotel": 5000, "hotel_invoice_uploaded": False})
        result = self.tool.run(claim)
        assert result.passed is False
        assert "hotel_invoice" in result.missing_documents

    def test_fails_when_flight_invoice_explicitly_false(self):
        claim = make_claim({"flight": 10000, "flight_invoice_uploaded": False})
        result = self.tool.run(claim)
        assert result.passed is False
        assert "flight_invoice" in result.missing_documents

    def test_passes_when_no_hotel_claimed(self):
        claim = make_claim({"hotel": 0})
        result = self.tool.run(claim)
        assert result.passed is True

    def test_notes_missing_invoice_number(self):
        # invoice_number=None with hotel/flight should note, but NOT fail
        claim = make_claim({"invoice_number": None})
        result = self.tool.run(claim)
        assert result.passed is True  # not a hard failure
        assert any("invoice_number" in note for note in result.notes)

    def test_notes_missing_travel_dates_when_hotel_claimed(self):
        claim = make_claim({"travel_start_date": None, "travel_end_date": None, "hotel": 5000})
        result = self.tool.run(claim)
        assert result.passed is True  # dates are advisory, not required
        assert any("travel_start_date" in note or "date" in note for note in result.notes)


# ── LimitCheckerTool ─────────────────────────────────────────────────────────

class TestLimitChecker:
    @pytest.fixture(autouse=True)
    def tool(self):
        from tools.limit_checker import LimitCheckerTool
        self.tool = LimitCheckerTool()

    def test_assignment_example_hotel_deduction(self, assignment_claim):
        """Assignment brief: hotel ₹6,200 > ₹5,000 cap → ₹1,200 deducted."""
        result = self.tool.run(assignment_claim)
        assert result.total_deduction == pytest.approx(1200, abs=0.01)
        assert result.capped_amount == pytest.approx(
            assignment_claim.total_claimed_amount - 1200, abs=0.01
        )

    def test_no_deduction_within_limits(self, clean_auto_claim):
        result = self.tool.run(clean_auto_claim)
        assert result.total_deduction == 0.0

    def test_meal_deduction(self):
        claim = make_claim({"meal": 2500, "hotel": 0, "flight": 0, "taxi": 0})
        result = self.tool.run(claim)
        # Domestic meal cap ₹1,000/day → deduct ₹1,500
        meal_ded = next(d for d in result.deductions if d.category == "meal")
        assert meal_ded.deduction == pytest.approx(1500, abs=0.01)

    def test_taxi_deduction(self):
        claim = make_claim({"taxi": 4000, "hotel": 0, "flight": 0, "meal": 0})
        result = self.tool.run(claim)
        # Domestic taxi cap ₹2,000/day → deduct ₹2,000
        taxi_ded = next(d for d in result.deductions if d.category == "taxi")
        assert taxi_ded.deduction == pytest.approx(2000, abs=0.01)

    def test_international_higher_limits(self, international_claim):
        # Hotel ₹11,000 < ₹12,000 international cap → no deduction
        result = self.tool.run(international_claim)
        hotel_ded = next((d for d in result.deductions if d.category == "hotel"), None)
        if hotel_ded:
            assert hotel_ded.within_limit is True

    def test_business_class_violation_flagged(self, business_class_claim):
        result = self.tool.run(business_class_claim)
        assert result.flight_class_violation is True
        assert result.flight_class_note is not None

    def test_economy_class_no_violation(self):
        claim = make_claim({"flight_class": "Economy"})
        result = self.tool.run(claim)
        assert result.flight_class_violation is False

    def test_unknown_category_detected(self, unknown_category_claim):
        result = self.tool.run(unknown_category_claim)
        assert "client_entertainment" in result.unknown_categories
        assert result.unknown_amount == pytest.approx(3000, abs=0.01)

    def test_multiple_deductions_cumulate(self):
        claim = make_claim({
            "hotel": 10000,   # excess ₹5,000
            "meal": 3000,     # excess ₹2,000
            "taxi": 5000,     # excess ₹3,000
        })
        result = self.tool.run(claim)
        assert result.total_deduction == pytest.approx(10000, abs=0.01)


# ── ApprovalCheckerTool ───────────────────────────────────────────────────────

class TestApprovalChecker:
    @pytest.fixture(autouse=True)
    def setup(self):
        from tools.approval_checker import ApprovalCheckerTool
        from tools.limit_checker import LimitCheckerTool
        from schemas import ApprovalLevel
        self.tool = ApprovalCheckerTool()
        self.limit_tool = LimitCheckerTool()
        self.ApprovalLevel = ApprovalLevel

    def _run(self, claim):
        limit_result = self.limit_tool.run(claim)
        return self.tool.run(claim, limit_result)

    def test_auto_below_10k(self, clean_auto_claim):
        result = self._run(clean_auto_claim)
        assert result.approval_level == self.ApprovalLevel.AUTO
        assert result.approver_role is None

    def test_manager_between_10k_and_50k(self, assignment_claim):
        # assignment claim total = ₹21,900 → Manager tier
        result = self._run(assignment_claim)
        assert result.approval_level == self.ApprovalLevel.MANAGER

    def test_finance_head_above_50k(self):
        claim = make_claim({"flight": 55000, "hotel": 0, "meal": 0, "taxi": 0})
        result = self._run(claim)
        assert result.approval_level == self.ApprovalLevel.FINANCE_HEAD

    def test_business_class_escalates_to_finance_head(self, business_class_claim):
        limit_result = self.limit_tool.run(business_class_claim)
        result = self.tool.run(business_class_claim, limit_result)
        assert result.approval_level == self.ApprovalLevel.FINANCE_HEAD
        assert result.escalated_for_policy_reason is not None


# ── DuplicateCheckerTool ──────────────────────────────────────────────────────

class TestDuplicateChecker:
    @pytest.fixture(autouse=True)
    def setup(self):
        import tempfile
        from pathlib import Path
        from ledger import ClaimsLedger
        from tools.duplicate_checker import DuplicateCheckerTool

        self.tmp = tempfile.NamedTemporaryFile(suffix=".json", delete=False)
        self.ledger = ClaimsLedger(Path(self.tmp.name))
        self.ledger.reset()
        self.tool = DuplicateCheckerTool(self.ledger)

    def teardown_method(self):
        Path(self.tmp.name).unlink(missing_ok=True)

    def _record(self, claim):
        """Simulate having previously processed a claim."""
        from datetime import datetime, timezone
        from ledger import LedgerEntry
        self.ledger.record(LedgerEntry(
            claim_id="CLM-PREV",
            trip_id=claim.trip_id or "TRIP-PREV",
            employee_id=claim.employee_id,
            invoice_number=claim.invoice_number,
            destination=claim.destination,
            travel_start_date=str(claim.travel_start_date) if claim.travel_start_date else None,
            travel_end_date=str(claim.travel_end_date) if claim.travel_end_date else None,
            trip_type=claim.trip_type.value,
            hotel=claim.hotel,
            flight=claim.flight,
            meal=claim.meal,
            taxi=claim.taxi,
            evaluated_at=datetime.now(timezone.utc).isoformat(),
        ))

    def test_no_duplicate_on_empty_ledger(self, assignment_claim):
        result = self.tool.run(assignment_claim)
        assert result.is_duplicate is False

    def test_exact_invoice_match(self):
        claim = make_claim({"invoice_number": "INV-DUP-001"})
        self._record(claim)
        # Resubmit the same claim
        result = self.tool.run(claim)
        assert result.is_duplicate is True
        assert result.match_type == "exact_invoice"
        assert result.confidence >= 0.9

    def test_different_invoice_not_duplicate(self):
        claim_a = make_claim({"invoice_number": "INV-A"})
        claim_b = make_claim({"invoice_number": "INV-B"})
        self._record(claim_a)
        result = self.tool.run(claim_b)
        assert result.is_duplicate is False

    def test_heuristic_amount_match(self):
        claim = make_claim({"invoice_number": None})
        self._record(claim)
        # Same amounts, no invoice_number → heuristic match
        result = self.tool.run(claim)
        assert result.is_duplicate is True
        assert result.match_type == "heuristic_amount_match"

    def test_different_employee_not_duplicate(self):
        original = make_claim({"invoice_number": "INV-EMP-001"})
        self._record(original)
        different_emp = make_claim({"employee_id": "EMP999", "invoice_number": "INV-EMP-001"})
        result = self.tool.run(different_emp)
        assert result.is_duplicate is False


# ── ValidatorTool ─────────────────────────────────────────────────────────────

class TestValidator:
    @pytest.fixture(autouse=True)
    def setup(self):
        import time
        from tools.validator import ValidatorTool
        from tools.receipt_checker import ReceiptCheckerTool
        from tools.limit_checker import LimitCheckerTool
        from tools.approval_checker import ApprovalCheckerTool
        from tests.conftest import make_claim, make_policy_result
        import tempfile
        from pathlib import Path
        from ledger import ClaimsLedger
        from tools.duplicate_checker import DuplicateCheckerTool

        self.validator = ValidatorTool()
        self.receipt_tool = ReceiptCheckerTool()
        self.limit_tool = LimitCheckerTool()
        self.approval_tool = ApprovalCheckerTool()
        tmp = tempfile.NamedTemporaryFile(suffix=".json", delete=False)
        ledger = ClaimsLedger(Path(tmp.name))
        self.dup_tool = DuplicateCheckerTool(ledger)
        self.start = time.monotonic()

    def _run_all_tools(self, claim, policy_low_confidence=False):
        from tests.conftest import make_policy_result
        receipt = self.receipt_tool.run(claim)
        limit = self.limit_tool.run(claim)
        approval = self.approval_tool.run(claim, limit)
        dup = self.dup_tool.run(claim)
        policy = make_policy_result(policy_low_confidence)
        return receipt, limit, approval, dup, policy

    def _make_llm_decision(self, approved, deduction, manual_review=False, confidence=0.95):
        from schemas import DecisionLabel, LLMDecision
        decision = DecisionLabel.PARTIALLY_APPROVED if deduction > 0 else DecisionLabel.APPROVED
        return LLMDecision(
            decision=decision,
            approved_amount=approved,
            deduction=deduction,
            manual_review=manual_review,
            policy_reference="Section 3: Hotel cap ₹5,000/night",
            confidence=confidence,
            missing_documents=[],
            reason="Hotel exceeded the domestic cap.",
        )

    def test_arithmetic_correction(self, assignment_claim):
        """LLM's deduction is wrong; validator must override."""
        receipt, limit, approval, dup, policy = self._run_all_tools(assignment_claim)
        # Tell the LLM it says ₹2,000 deduction (wrong; correct is ₹1,200)
        llm_dec = self._make_llm_decision(approved=19900, deduction=2000)
        result = self.validator.run(
            claim=assignment_claim,
            llm_decision=llm_dec,
            receipt_result=receipt,
            limit_result=limit,
            approval_result=approval,
            duplicate_result=dup,
            policy_low_confidence=False,
            model_name="test-model",
            execution_start=self.start,
        )
        assert result.deduction == pytest.approx(1200, abs=0.01)
        assert result.approved_amount == pytest.approx(
            assignment_claim.hotel + assignment_claim.flight + assignment_claim.meal + assignment_claim.taxi - 1200,
            abs=0.01,
        )
        # An override should create a ValidationIssue
        assert any("deduction" in issue.field for issue in result.validation_issues)

    def test_manual_review_forced_on_missing_receipt(self, missing_receipt_claim):
        receipt, limit, approval, dup, policy = self._run_all_tools(missing_receipt_claim)
        llm_dec = self._make_llm_decision(
            approved=missing_receipt_claim.total_claimed_amount,
            deduction=0,
            manual_review=False,  # LLM says no manual review – validator should override
        )
        result = self.validator.run(
            claim=missing_receipt_claim,
            llm_decision=llm_dec,
            receipt_result=receipt,
            limit_result=limit,
            approval_result=approval,
            duplicate_result=dup,
            policy_low_confidence=False,
            model_name="test-model",
            execution_start=self.start,
        )
        assert result.manual_review is True

    def test_low_policy_confidence_forces_manual_review(self, assignment_claim):
        receipt, limit, approval, dup, policy = self._run_all_tools(
            assignment_claim, policy_low_confidence=True
        )
        llm_dec = self._make_llm_decision(approved=20700, deduction=1200, manual_review=False)
        result = self.validator.run(
            claim=assignment_claim,
            llm_decision=llm_dec,
            receipt_result=receipt,
            limit_result=limit,
            approval_result=approval,
            duplicate_result=dup,
            policy_low_confidence=True,
            model_name="test-model",
            execution_start=self.start,
        )
        assert result.manual_review is True

    def test_decision_label_fixed_zero_deduction(self, clean_auto_claim):
        receipt, limit, approval, dup, policy = self._run_all_tools(clean_auto_claim)
        from schemas import DecisionLabel, LLMDecision
        # LLM incorrectly says Partially Approved with 0 deduction
        llm_dec = LLMDecision(
            decision=DecisionLabel.PARTIALLY_APPROVED,
            approved_amount=clean_auto_claim.total_claimed_amount,
            deduction=0.0,
            manual_review=False,
            policy_reference="Policy: within all limits.",
            confidence=0.99,
            missing_documents=[],
            reason="All within limits.",
        )
        result = self.validator.run(
            claim=clean_auto_claim,
            llm_decision=llm_dec,
            receipt_result=receipt,
            limit_result=limit,
            approval_result=approval,
            duplicate_result=dup,
            policy_low_confidence=False,
            model_name="test-model",
            execution_start=self.start,
        )
        assert result.decision.value == "Approved"
