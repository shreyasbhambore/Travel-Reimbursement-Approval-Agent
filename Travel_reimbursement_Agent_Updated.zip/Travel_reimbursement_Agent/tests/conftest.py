"""
Shared pytest fixtures.

These are injected into any test that declares the matching parameter name.
The fixtures intentionally avoid importing ML-heavy dependencies (faiss,
sentence-transformers) at import time; those are either never needed (tool
tests use mock retrievers) or are skipped automatically if the deps aren't
installed (e2e tests that actually need the vector store).
"""
from __future__ import annotations

import os
import sys
from datetime import date
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest

# Ensure project root is on the Python path when running tests from tests/
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from schemas import (
    FlightClass,
    PolicyChunk,
    PolicyRetrievalResult,
    TravelClaim,
    TripType,
)


# ── Mock helpers ──────────────────────────────────────────────────────────────

def make_claim(overrides: dict | None = None) -> TravelClaim:
    """The canonical "assignment example" claim, with optional field overrides."""
    base = {
        "employee_id": "EMP001",
        "name": "John Doe",
        "trip_type": "Domestic",
        "hotel": 6200,
        "flight": 14000,
        "meal": 900,
        "taxi": 800,
        "receipt_uploaded": True,
    }
    base.update(overrides or {})
    return TravelClaim.model_validate(base)


def make_policy_result(low_confidence: bool = False) -> PolicyRetrievalResult:
    """Lightweight mock of a successful policy retrieval."""
    chunk = PolicyChunk(
        content=(
            "Hotel accommodation is reimbursable up to ₹5,000 per night for Domestic trips. "
            "Meal allowance is ₹1,000 per day. Taxi is capped at ₹2,000 per day."
        ),
        source="travel_policy.md",
        score=0.85 if not low_confidence else 0.20,
    )
    return PolicyRetrievalResult(
        chunks=[chunk],
        query="hotel limit meal taxi",
        top_score=chunk.score,
        low_confidence=low_confidence,
    )


class MockRetriever:
    """Stub `PolicyRetriever` that never touches FAISS."""

    def __init__(self, low_confidence: bool = False):
        self._low_confidence = low_confidence

    def retrieve(self, query: str) -> PolicyRetrievalResult:
        return make_policy_result(self._low_confidence)


# ── pytest fixtures ───────────────────────────────────────────────────────────

@pytest.fixture
def assignment_claim() -> TravelClaim:
    """Exact claim from the assignment brief."""
    return make_claim()


@pytest.fixture
def clean_auto_claim() -> TravelClaim:
    """Fully compliant domestic claim under the ₹10,000 auto-approval threshold."""
    return make_claim({
        "employee_id": "EMP002",
        "name": "Asha Mehta",
        "hotel": 3000,
        "flight": 4000,
        "meal": 600,
        "taxi": 500,
        "invoice_number": "INV-FIXTURE-001",
    })


@pytest.fixture
def missing_receipt_claim() -> TravelClaim:
    """Claim where receipt_uploaded=False, so manual_review must be forced."""
    return make_claim({"receipt_uploaded": False})


@pytest.fixture
def business_class_claim() -> TravelClaim:
    """Business-class domestic trip without pre-approval flag."""
    return make_claim({
        "flight_class": "Business",
        "flight_class_pre_approved": False,
    })


@pytest.fixture
def international_claim() -> TravelClaim:
    return make_claim({
        "trip_type": "International",
        "hotel": 11000,
        "flight": 40000,
        "meal": 2000,
        "taxi": 3000,
        "receipt_uploaded": True,
    })


@pytest.fixture
def unknown_category_claim() -> TravelClaim:
    return make_claim({
        "other_expenses": {"client_entertainment": 3000},
    })
