"""
FastAPI endpoint tests.

The LangGraph graph is replaced with a lightweight stub so these tests do not
need a Groq API key, a running FAISS index, or any ML dependencies. We test:
  - POST /evaluate-claim: happy path, validation errors, service-unavailable
  - GET /health: status fields
"""
from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest
from fastapi.testclient import TestClient

# We need to patch the lifespan before importing app so the real startup
# (which tries to build FAISS) never runs during testing.
from schemas import (
    ApprovalLevel,
    ClaimDecision,
    DecisionLabel,
    TravelClaim,
)


def _make_claim_decision(claim: TravelClaim) -> ClaimDecision:
    """Synthetic ClaimDecision that mimics what the real graph would return."""
    return ClaimDecision(
        claim_id="CLM-TESTABCD",
        trip_id=claim.trip_id or "TRIP-TEST",
        employee_id=claim.employee_id,
        employee_name=claim.name,
        decision=DecisionLabel.PARTIALLY_APPROVED,
        approved_amount=20700.0,
        deduction=1200.0,
        manual_review=False,
        policy_reference="Section 3: Hotel cap ₹5,000/night for Domestic trips.",
        confidence=0.96,
        missing_documents=[],
        reason="Hotel expense exceeded the domestic cap; ₹1,200 deducted.",
        approval_level=ApprovalLevel.MANAGER,
        approver_role="Direct Manager",
        duplicate_suspected=False,
        total_claimed_amount=21900.0,
        validation_issues=[],
        evaluated_at=datetime.now(timezone.utc),
        execution_time_ms=250.0,
        model_used="openai/gpt-oss-120b",
    )


@pytest.fixture
def client():
    """TestClient with mocked lifespan so no real startup/shutdown occurs."""
    from contextlib import asynccontextmanager

    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    # Patch the real app's _app_state
    import app as app_module

    mock_graph = MagicMock()

    def fake_invoke(state):
        claim = state["claim"]
        return {"final_decision": _make_claim_decision(claim)}

    mock_graph.invoke.side_effect = fake_invoke

    # IMPORTANT: TestClient triggers the real FastAPI `lifespan` on __enter__,
    # which would otherwise overwrite `_app_state["graph"]` with the outcome
    # of the *real* startup (ingestion, ChatGroq wiring, etc). We must install
    # the mock AFTER startup has run, not before, or it gets clobbered.
    with TestClient(app_module.app, raise_server_exceptions=True) as c:
        app_module._app_state["graph"] = mock_graph
        app_module._app_state["vector_store_ready"] = True
        yield c


# ── /health ───────────────────────────────────────────────────────────────────

class TestHealthEndpoint:
    def test_health_returns_200(self, client):
        response = client.get("/health")
        assert response.status_code == 200

    def test_health_schema(self, client):
        data = response = client.get("/health").json()
        assert "status" in data
        assert "version" in data
        assert "vector_store_ready" in data
        assert "groq_configured" in data


# ── POST /evaluate-claim ─────────────────────────────────────────────────────

ASSIGNMENT_CLAIM = {
    "employee_id": "EMP001",
    "name": "John Doe",
    "trip_type": "Domestic",
    "hotel": 6200,
    "flight": 14000,
    "meal": 900,
    "taxi": 800,
    "receipt_uploaded": True,
}


class TestEvaluateClaim:
    def test_returns_200_with_valid_payload(self, client):
        response = client.post("/evaluate-claim", json=ASSIGNMENT_CLAIM)
        assert response.status_code == 200

    def test_response_contains_required_fields(self, client):
        data = client.post("/evaluate-claim", json=ASSIGNMENT_CLAIM).json()
        required_fields = [
            "decision",
            "approved_amount",
            "deduction",
            "manual_review",
            "policy_reference",
            "confidence",
            "missing_documents",
            "reason",
        ]
        for field in required_fields:
            assert field in data, f"Missing required field: {field}"

    def test_decision_is_valid_label(self, client):
        data = client.post("/evaluate-claim", json=ASSIGNMENT_CLAIM).json()
        assert data["decision"] in [v.value for v in DecisionLabel]

    def test_approved_amount_is_numeric(self, client):
        data = client.post("/evaluate-claim", json=ASSIGNMENT_CLAIM).json()
        assert isinstance(data["approved_amount"], (int, float))
        assert data["approved_amount"] >= 0

    def test_deduction_is_non_negative(self, client):
        data = client.post("/evaluate-claim", json=ASSIGNMENT_CLAIM).json()
        assert data["deduction"] >= 0

    def test_missing_documents_is_list(self, client):
        data = client.post("/evaluate-claim", json=ASSIGNMENT_CLAIM).json()
        assert isinstance(data["missing_documents"], list)

    def test_missing_required_field_returns_422(self, client):
        bad_payload = {k: v for k, v in ASSIGNMENT_CLAIM.items() if k != "employee_id"}
        response = client.post("/evaluate-claim", json=bad_payload)
        assert response.status_code == 422

    def test_invalid_trip_type_returns_422(self, client):
        bad_payload = {**ASSIGNMENT_CLAIM, "trip_type": "Interplanetary"}
        response = client.post("/evaluate-claim", json=bad_payload)
        assert response.status_code == 422

    def test_negative_expense_returns_422(self, client):
        bad_payload = {**ASSIGNMENT_CLAIM, "hotel": -100}
        response = client.post("/evaluate-claim", json=bad_payload)
        assert response.status_code == 422

    def test_swagger_docs_accessible(self, client):
        response = client.get("/docs")
        assert response.status_code == 200

    def test_openapi_schema_accessible(self, client):
        response = client.get("/openapi.json")
        assert response.status_code == 200
        schema = response.json()
        assert "/evaluate-claim" in schema["paths"]

    def test_graph_unavailable_returns_503(self):
        """When the graph is None (vector store failed at startup), the endpoint
        should return 503, not 500."""
        import app as app_module
        from fastapi.testclient import TestClient

        original = app_module._app_state.get("graph")
        try:
            with TestClient(app_module.app, raise_server_exceptions=False) as c:
                # Force this AFTER startup so the real lifespan can't override it.
                app_module._app_state["graph"] = None
                response = c.post("/evaluate-claim", json=ASSIGNMENT_CLAIM)
            assert response.status_code == 503
        finally:
            app_module._app_state["graph"] = original

    def test_extra_optional_fields_accepted(self, client):
        """The API should accept the enriched payload with optional fields."""
        enriched = {
            **ASSIGNMENT_CLAIM,
            "invoice_number": "INV-2026-TEST",
            "destination": "Mumbai",
            "department": "Engineering",
            "flight_class": "Economy",
            "travel_start_date": "2026-06-01",
            "travel_end_date": "2026-06-03",
        }
        response = client.post("/evaluate-claim", json=enriched)
        assert response.status_code == 200

    def test_international_trip_accepted(self, client):
        intl_payload = {
            "employee_id": "EMP003",
            "name": "Rohan Verma",
            "trip_type": "International",
            "hotel": 11000,
            "flight": 40000,
            "meal": 2000,
            "taxi": 3000,
            "receipt_uploaded": True,
        }
        response = client.post("/evaluate-claim", json=intl_payload)
        assert response.status_code == 200
