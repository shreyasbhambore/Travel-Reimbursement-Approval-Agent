"""
Tool 3 – Expense Limit Checker

Applies the company's per-category spending caps (loaded from `data/limits.json`)
to each line item of the claim and computes the exact monetary deduction for
each category that exceeds its cap.

This is the only place in the codebase where the approved-amount / deduction
arithmetic is computed. The final output-validator node cross-checks the LLM's
produced figures against these results and overrides any discrepancy, ensuring
that monetary arithmetic is always done by deterministic code and not an LLM.

Design note: the policy caps are per-*night* (hotel) and per-*day* (meal, taxi)
but the claim payload from the assignment brief carries only aggregate amounts,
not a trip-day count. Therefore we treat each aggregate amount as if it
corresponds to exactly one night / one day and cap it at the single-period limit.
This is the most conservative interpretation (it under-approves less). A future
version should accept a nights/days field; see README "Design Decisions".
"""
from __future__ import annotations

import json
import time
from typing import List, Optional

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from config import get_settings
from logging_config import get_logger
from schemas import (
    ApprovalCheckResult,
    ApprovalLevel,
    FlightClass,
    LimitCheckResult,
    LimitDeduction,
    TravelClaim,
    TripType,
)

logger = get_logger(__name__)

ALWAYS_NEEDS_FINANCE_HEAD = {FlightClass.BUSINESS, FlightClass.FIRST}


class LimitCheckerInput(BaseModel):
    claim_json: str = Field(..., description="JSON-encoded TravelClaim payload.")


class LimitCheckerTool:
    """Deterministic limit-enforcement tool. Loaded once and shared across
    requests (limits.json is static at startup)."""

    def __init__(self):
        settings = get_settings()
        self._limits = json.loads(settings.LIMITS_PATH.read_text(encoding="utf-8"))

    def _get_limits_for_trip(self, trip_type: TripType) -> dict:
        return self._limits["limits"][trip_type.value]

    def run(self, claim: TravelClaim) -> LimitCheckResult:
        start = time.monotonic()
        trip_limits = self._get_limits_for_trip(claim.trip_type)
        deductions: List[LimitDeduction] = []

        def check(
            category: str,
            claimed: float,
            limit_key: str,
            period_label: str,
        ) -> None:
            limit: Optional[float] = trip_limits.get(limit_key)
            if claimed == 0:
                return  # Not claimed; nothing to enforce.
            if limit is None:
                logger.warning("No limit configured for %s/%s", claim.trip_type.value, limit_key)
                deductions.append(
                    LimitDeduction(
                        category=category,
                        claimed=claimed,
                        limit=None,
                        deduction=0.0,
                        within_limit=True,
                        note=f"No cap configured for {category} on {claim.trip_type.value} trips.",
                    )
                )
                return
            excess = max(0.0, round(claimed - limit, 2))
            deductions.append(
                LimitDeduction(
                    category=category,
                    claimed=claimed,
                    limit=limit,
                    deduction=excess,
                    within_limit=(excess == 0.0),
                    note=(
                        f"Within limit (₹{limit:,.0f}/{period_label})."
                        if excess == 0.0
                        else f"Exceeds {claim.trip_type.value} cap of ₹{limit:,.0f}/{period_label}; "
                        f"₹{excess:,.2f} deducted."
                    ),
                )
            )

        check("hotel", claim.hotel, "hotel_per_night", "night")
        check("flight", claim.flight, "flight_per_night", "trip")  # flight has no hard INR cap
        check("meal", claim.meal, "meal_per_day", "day")
        check("taxi", claim.taxi, "taxi_per_day", "day")

        # Flight has no INR cap in the policy, only a class restriction.
        # Remove any zero-deduction placeholder added for flight by _check
        # so the deductions list stays clean for the validator.
        # (check() never adds flight to deductions if flight==0, so no-op
        # for zero-flight claims.)

        # Flight class check
        flight_class_violation = False
        flight_class_note: Optional[str] = None

        if claim.flight > 0:
            fc = claim.flight_class
            allowed: list = trip_limits.get("allowed_flight_classes", ["Economy"])
            conditional: dict = trip_limits.get("conditional_flight_classes", {})

            if fc.value in ALWAYS_NEEDS_FINANCE_HEAD and not claim.flight_class_pre_approved:
                flight_class_violation = True
                flight_class_note = (
                    f"{fc.value} class requires Finance Head pre-approval regardless of trip "
                    f"type or duration. Escalated for Finance Head review."
                )
            elif fc.value not in allowed and fc.value in conditional:
                # Conditional class (e.g. Premium Economy for long international) – we do
                # NOT auto-approve but we also don't flag a hard violation; it requires a
                # human to confirm pre-approval was given.
                flight_class_note = conditional[fc.value]
            elif fc.value not in allowed:
                flight_class_violation = True
                flight_class_note = (
                    f"{fc.value} class is not listed as allowed for {claim.trip_type.value} "
                    "trips and has no pre-approval path; routed to manual review."
                )

        # Unknown expense categories
        unknown_categories: List[str] = []
        unknown_amount: float = 0.0
        if claim.other_expenses:
            for cat, amt in claim.other_expenses.items():
                unknown_categories.append(cat)
                unknown_amount += amt

        base_claimed = round(
            sum(d.claimed for d in deductions if d.category in ("hotel", "flight", "meal", "taxi")),
            2,
        )
        # Re-compute from claim directly to avoid any rounding drift from deductions list.
        base_claimed = round(claim.hotel + claim.flight + claim.meal + claim.taxi, 2)
        total_deduction = round(sum(d.deduction for d in deductions), 2)
        capped_amount = round(base_claimed - total_deduction, 2)

        result = LimitCheckResult(
            trip_type=claim.trip_type,
            deductions=deductions,
            total_deduction=total_deduction,
            base_claimed_amount=base_claimed,
            capped_amount=capped_amount,
            unknown_categories=unknown_categories,
            unknown_amount=round(unknown_amount, 2),
            flight_class_violation=flight_class_violation,
            flight_class_note=flight_class_note,
        )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        logger.info(
            "TOOL limit_checker | elapsed_ms=%.1f | trip=%s | deduction=₹%.2f | "
            "capped=₹%.2f | violations=%s | unknown_cats=%s",
            elapsed,
            claim.trip_type.value,
            total_deduction,
            capped_amount,
            [d.category for d in deductions if not d.within_limit] or "none",
            unknown_categories or "none",
        )
        return result

    def _tool_fn(self, claim_json: str) -> str:
        claim = TravelClaim.model_validate(json.loads(claim_json))
        result = self.run(claim)
        lines = [
            f"Expense Limit Check ({result.trip_type.value}):",
            f"  Total base claimed: ₹{result.base_claimed_amount:,.2f}",
            f"  Total deduction:    ₹{result.total_deduction:,.2f}",
            f"  Capped amount:      ₹{result.capped_amount:,.2f}",
        ]
        for d in result.deductions:
            lines.append(f"  [{d.category}] {d.note}")
        if result.flight_class_violation:
            lines.append(f"  [FLIGHT CLASS VIOLATION] {result.flight_class_note}")
        elif result.flight_class_note:
            lines.append(f"  [FLIGHT CLASS NOTE] {result.flight_class_note}")
        if result.unknown_categories:
            lines.append(
                f"  [UNKNOWN CATEGORIES] {result.unknown_categories} – ₹{result.unknown_amount:,.2f} "
                "total; requires manual review."
            )
        return "\n".join(lines)

    def as_langchain_tool(self) -> StructuredTool:
        return StructuredTool(
            name="limit_checker",
            description=(
                "Applies company travel expense limits to each category (hotel, meal, taxi, flight "
                "class) and returns the exact deduction for any amount exceeding its cap, the total "
                "deduction, and the capped reimbursable amount. Also flags flight-class violations "
                "and unknown expense categories."
            ),
            args_schema=LimitCheckerInput,
            func=self._tool_fn,
        )
