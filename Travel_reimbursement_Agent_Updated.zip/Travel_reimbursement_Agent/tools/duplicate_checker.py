"""
Tool 5 – Duplicate Claim Checker

Checks the claims ledger to determine whether the incoming claim looks like a
re-submission of one already processed. Three escalating match strategies are
applied in priority order:

1. Exact invoice match: same employee_id AND same invoice_number.
   High-confidence; only fires when both claim and ledger entry have an
   invoice_number.

2. Trip window match: same employee_id, same destination, and overlapping
   travel date ranges. Medium-confidence; only fires when both claims have
   full date and destination information.

3. Amount heuristic: same employee_id, trip_type, and identical amounts
   across all four categories. Low-confidence signal -- might be a legitimate
   recurring trip at the same cost, but worth surfacing.

Policy: ANY suspected duplicate is forced to manual_review=True, regardless of
the match confidence level. The agent never auto-rejects on a duplicate
suspicion alone (Finance must investigate).
"""
from __future__ import annotations

import time

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from ledger import ClaimsLedger
from logging_config import get_logger
from schemas import DuplicateCheckResult, TravelClaim

logger = get_logger(__name__)


class DuplicateCheckerInput(BaseModel):
    claim_json: str = Field(..., description="JSON-encoded TravelClaim payload.")


class DuplicateCheckerTool:
    def __init__(self, ledger: ClaimsLedger):
        self._ledger = ledger

    def run(self, claim: TravelClaim) -> DuplicateCheckResult:
        start = time.monotonic()

        # Strategy 1: exact invoice match (highest confidence)
        if claim.invoice_number:
            match = self._ledger.find_by_invoice(claim.employee_id, claim.invoice_number)
            if match:
                elapsed = round((time.monotonic() - start) * 1000, 2)
                result = DuplicateCheckResult(
                    is_duplicate=True,
                    match_type="exact_invoice",
                    matched_trip_id=match.trip_id,
                    confidence=0.98,
                    notes=(
                        f"Invoice number {claim.invoice_number!r} already processed for "
                        f"employee {claim.employee_id} under trip {match.trip_id}."
                    ),
                )
                logger.warning(
                    "TOOL duplicate_checker | DUPLICATE (exact_invoice) | elapsed_ms=%.1f | "
                    "invoice=%s | employee=%s | matched_trip=%s",
                    elapsed,
                    claim.invoice_number,
                    claim.employee_id,
                    match.trip_id,
                )
                return result

        # Strategy 2: trip window match (medium confidence)
        match = self._ledger.find_overlapping_trip(
            claim.employee_id,
            claim.destination,
            claim.travel_start_date,
            claim.travel_end_date,
        )
        if match:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            result = DuplicateCheckResult(
                is_duplicate=True,
                match_type="trip_window",
                matched_trip_id=match.trip_id,
                confidence=0.80,
                notes=(
                    f"Overlapping trip found for employee {claim.employee_id} to "
                    f"{claim.destination!r} ({claim.travel_start_date} – {claim.travel_end_date}) "
                    f"already on record as trip {match.trip_id}."
                ),
            )
            logger.warning(
                "TOOL duplicate_checker | DUPLICATE (trip_window) | elapsed_ms=%.1f | "
                "employee=%s | destination=%s | matched_trip=%s",
                elapsed,
                claim.employee_id,
                claim.destination,
                match.trip_id,
            )
            return result

        # Strategy 3: heuristic amount match (low confidence)
        match = self._ledger.find_amount_heuristic_match(
            claim.employee_id,
            claim.trip_type.value,
            claim.hotel,
            claim.flight,
            claim.meal,
            claim.taxi,
            invoice_number=claim.invoice_number,
        )
        if match:
            elapsed = round((time.monotonic() - start) * 1000, 2)
            result = DuplicateCheckResult(
                is_duplicate=True,
                match_type="heuristic_amount_match",
                matched_trip_id=match.trip_id,
                confidence=0.50,
                notes=(
                    f"Identical amounts across all categories for employee {claim.employee_id} "
                    f"({claim.trip_type.value}) found in trip {match.trip_id}. "
                    "Low confidence – may be a coincidence on a recurring route."
                ),
            )
            logger.info(
                "TOOL duplicate_checker | POSSIBLE DUPLICATE (heuristic) | elapsed_ms=%.1f | "
                "employee=%s | matched_trip=%s",
                elapsed,
                claim.employee_id,
                match.trip_id,
            )
            return result

        elapsed = round((time.monotonic() - start) * 1000, 2)
        logger.info(
            "TOOL duplicate_checker | no duplicate | elapsed_ms=%.1f | employee=%s",
            elapsed,
            claim.employee_id,
        )
        return DuplicateCheckResult(is_duplicate=False, confidence=0.0, notes="No prior matching claim found.")

    def _tool_fn(self, claim_json: str) -> str:
        import json

        claim = TravelClaim.model_validate(json.loads(claim_json))
        result = self.run(claim)
        if result.is_duplicate:
            return (
                f"DUPLICATE SUSPECTED | match_type={result.match_type} | "
                f"confidence={result.confidence:.2f}\n{result.notes}"
            )
        return "No duplicate found."

    def as_langchain_tool(self) -> StructuredTool:
        return StructuredTool(
            name="duplicate_checker",
            description=(
                "Checks whether an identical or overlapping claim has already been processed "
                "for this employee. Returns DUPLICATE SUSPECTED with a confidence score, or "
                "'No duplicate found.' A duplicate result always forces manual review."
            ),
            args_schema=DuplicateCheckerInput,
            func=self._tool_fn,
        )
