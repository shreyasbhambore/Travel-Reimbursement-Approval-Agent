"""
Tool 1 – Policy Lookup

Retrieves relevant sections of the corporate travel policy from FAISS and
returns them as a formatted string. Registered as a LangChain StructuredTool
so it can be bound to the model and invoked from the LangGraph agent node
*or* called directly from the deterministic workflow nodes.
"""
from __future__ import annotations

import time
from typing import Optional

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from logging_config import get_logger
from rag.retriever import PolicyRetriever
from schemas import PolicyRetrievalResult

logger = get_logger(__name__)


class PolicyLookupInput(BaseModel):
    query: str = Field(
        ...,
        description="Natural-language description of the expense scenario or policy area to look up. "
        "Examples: 'hotel nightly cap Domestic trip', 'flight class reimbursement rules', "
        "'approval routing for claims above 50000 rupees'.",
    )


class PolicyLookupTool:
    """Wrapper that bundles the retriever and exposes both a programmatic
    `.run(query)` method (used by workflow nodes) and a LangChain
    StructuredTool (used when binding tools to the LLM)."""

    def __init__(self, retriever: PolicyRetriever):
        self._retriever = retriever

    def run(self, query: str) -> PolicyRetrievalResult:
        """Direct programmatic call: returns the full `PolicyRetrievalResult`
        (including scores and the `low_confidence` flag)."""
        start = time.monotonic()
        result = self._retriever.retrieve(query)
        elapsed = round((time.monotonic() - start) * 1000, 2)
        logger.info(
            "TOOL policy_lookup | elapsed_ms=%.1f | top_score=%.4f | chunks=%d | query=%r",
            elapsed,
            result.top_score,
            len(result.chunks),
            query,
        )
        return result

    def _tool_fn(self, query: str) -> str:
        """String-returning variant for use as a LangChain tool function. The
        LLM sees this when the tool is bound to the model. Returns a
        human-readable block containing all retrieved policy text."""
        result = self.run(query)
        if not result.chunks:
            return "No relevant policy sections found."
        parts = ["[POLICY CONTEXT RETRIEVED]\n"]
        for i, chunk in enumerate(result.chunks, 1):
            parts.append(f"--- Section {i} (relevance {chunk.score:.3f}) ---\n{chunk.content}")
        if result.low_confidence:
            parts.append(
                "\n[NOTE] Retrieval confidence is low – the above sections may not directly "
                "address this scenario. A human reviewer should verify policy applicability."
            )
        return "\n\n".join(parts)

    def as_langchain_tool(self) -> StructuredTool:
        return StructuredTool(
            name="policy_lookup",
            description=(
                "Searches the company travel & expense reimbursement policy. "
                "Use it to look up per-night hotel caps, meal allowances, taxi limits, "
                "flight-class rules, approval thresholds, and documentation requirements. "
                "Returns the most relevant policy sections as text."
            ),
            args_schema=PolicyLookupInput,
            func=self._tool_fn,
        )
