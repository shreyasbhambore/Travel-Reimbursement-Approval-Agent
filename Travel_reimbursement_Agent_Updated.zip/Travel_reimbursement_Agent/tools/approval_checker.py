"""
Tool 4 – Approval Matrix Checker

Routes the claim to the correct human-approval tier (Auto / Manager /
FinanceHead) based on the total *claimed* amount and the approval matrix in
`data/approval_matrix.json`.

Important distinction from the assignment brief: the approval tier tells you
*who must sign off for disbursement*, not whether the AI agent's own decision
is trustworthy. `manual_review` (computed in the validation node) is a
separate flag that tells Finance *whether the AI's reasoning should be
double-checked by a human*. A claim can be confidently decided by the AI
(manual_review=False) and still require Manager sign-off just because it is
large. See README "Design Decisions" and schemas.py docstrings.
"""
from __future__ import annotations

import json
import time

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from config import get_settings
from logging_config import get_logger
from schemas import ApprovalCheckResult, ApprovalLevel, LimitCheckResult, TravelClaim

logger = get_logger(__name__)

FINANCE_HEAD_FLIGHT_CLASSES = {"Business", "First"}


class ApprovalCheckerInput(BaseModel):
    claim_json: str = Field(..., description="JSON-encoded TravelClaim payload.")
    limit_result_json: str = Field(
        ..., description="JSON-encoded LimitCheckResult; needed for flight-class escalation logic."
    )


class ApprovalCheckerTool:
    def __init__(self):
        settings = get_settings()
        self._matrix = json.loads(settings.APPROVAL_MATRIX_PATH.read_text(encoding="utf-8"))

    def _tier_for_amount(self, amount: float) -> dict:
        for tier in self._matrix["tiers"]:
            max_amt = tier.get("max_amount")
            inclusive = tier.get("max_amount_inclusive", False)
            if max_amt is None:
                return tier
            if inclusive and amount <= max_amt:
                return tier
            if not inclusive and amount < max_amt:
                return tier
        return self._matrix["tiers"][-1]  # fallback – highest tier

    def run(self, claim: TravelClaim, limit_result: LimitCheckResult) -> ApprovalCheckResult:
        start = time.monotonic()
        basis_amount = claim.total_claimed_amount
        tier = self._tier_for_amount(basis_amount)
        level = ApprovalLevel(tier["level"])
        approver_role = tier.get("approver_role")
        escalated_for: str | None = None

        # Flight-class violations always require Finance Head, regardless of amount.
        if limit_result.flight_class_violation and level != ApprovalLevel.FINANCE_HEAD:
            level = ApprovalLevel.FINANCE_HEAD
            approver_role = "Finance Head"
            escalated_for = (
                f"Flight class violation detected ({claim.flight_class.value}). "
                "Policy requires Finance Head pre-approval for Business/First class."
            )

        rationale = (
            f"Total claimed amount ₹{basis_amount:,.2f} falls in the '{tier['level']}' tier "
            f"(description: {tier['description']}). "
            + (f"Escalated: {escalated_for}" if escalated_for else "No escalation applied.")
        )

        result = ApprovalCheckResult(
            approval_level=level,
            approver_role=approver_role,
            threshold_basis_amount=basis_amount,
            escalated_for_policy_reason=escalated_for,
            rationale=rationale,
        )

        elapsed = round((time.monotonic() - start) * 1000, 2)
        logger.info(
            "TOOL approval_checker | elapsed_ms=%.1f | amount=₹%.2f | level=%s | approver=%s%s",
            elapsed,
            basis_amount,
            level.value,
            approver_role or "none",
            f" | escalated: {escalated_for}" if escalated_for else "",
        )
        return result

    def _tool_fn(self, claim_json: str, limit_result_json: str) -> str:
        claim = TravelClaim.model_validate(json.loads(claim_json))
        limit_result = LimitCheckResult.model_validate(json.loads(limit_result_json))
        result = self.run(claim, limit_result)
        return (
            f"Approval tier: {result.approval_level.value}\n"
            f"Approver role: {result.approver_role or 'none (auto-approved)'}\n"
            f"Basis amount: ₹{result.threshold_basis_amount:,.2f}\n"
            f"Rationale: {result.rationale}"
        )

    def as_langchain_tool(self) -> StructuredTool:
        return StructuredTool(
            name="approval_checker",
            description=(
                "Determines which human-approval tier a claim requires for disbursement sign-off, "
                "based on the total claimed amount and flight-class violations. "
                "Returns Auto (no human needed), Manager, or FinanceHead."
            ),
            args_schema=ApprovalCheckerInput,
            func=self._tool_fn,
        )
