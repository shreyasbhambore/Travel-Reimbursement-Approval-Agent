"""
Tool 2 – Receipt Checker

Validates that all required documentation is present on a claim:
- General receipt flag (`receipt_uploaded`)
- Hotel invoice (`hotel_invoice_uploaded`, required when hotel > 0)
- Flight invoice (`flight_invoice_uploaded`, required when flight > 0)
- Invoice number (required when a specific hotel or flight is claimed)
- Travel dates (expected when hotel is claimed -- used by duplicate detection)

Any missing item is appended to `missing_documents`, and if ANY item is
missing the `passed` flag is False, which forces `manual_review=True` in
the graph.
"""
from __future__ import annotations

import time
from typing import List

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from logging_config import get_logger
from schemas import ReceiptCheckResult, TravelClaim

logger = get_logger(__name__)


class ReceiptCheckerInput(BaseModel):
    claim_json: str = Field(
        ..., description="JSON-encoded TravelClaim payload."
    )


class ReceiptCheckerTool:
    """Deterministic document-presence validator. No ML involved: it purely
    checks flags and field values, so its output is always reproducible and
    unit-testable without any mocking."""

    def run(self, claim: TravelClaim) -> ReceiptCheckResult:
        start = time.monotonic()
        missing: List[str] = []
        notes: List[str] = []

        # 1 ── General receipt upload flag
        if not claim.receipt_uploaded:
            missing.append("receipt")
            notes.append("receipt_uploaded is False; no reimbursement can proceed without proof of payment.")

        # 2 ── Hotel invoice (only required when hotel expenses are claimed)
        if claim.hotel > 0:
            if claim.hotel_invoice_uploaded is False:
                missing.append("hotel_invoice")
                notes.append("hotel_invoice_uploaded explicitly set to False while hotel > 0.")
            elif claim.hotel_invoice_uploaded is None:
                # Field was omitted – apply the same logic as receipt_uploaded
                if not claim.receipt_uploaded:
                    missing.append("hotel_invoice")
                    notes.append(
                        "hotel_invoice_uploaded not provided and receipt_uploaded is False; "
                        "hotel invoice status unknown."
                    )

        # 3 ── Flight invoice (only required when flight expenses are claimed)
        if claim.flight > 0:
            if claim.flight_invoice_uploaded is False:
                missing.append("flight_invoice")
                notes.append("flight_invoice_uploaded explicitly set to False while flight > 0.")
            elif claim.flight_invoice_uploaded is None:
                if not claim.receipt_uploaded:
                    missing.append("flight_invoice")
                    notes.append(
                        "flight_invoice_uploaded not provided and receipt_uploaded is False; "
                        "flight invoice status unknown."
                    )

        # 4 ── Invoice number
        if claim.invoice_number is None and (claim.hotel > 0 or claim.flight > 0):
            notes.append(
                "invoice_number not provided. Recommended for hotel/flight claims to enable "
                "duplicate detection; claim can still proceed if other checks pass."
            )

        # 5 ── Travel dates
        if claim.travel_start_date is None or claim.travel_end_date is None:
            if claim.hotel > 0:
                notes.append(
                    "travel_start_date / travel_end_date not provided. Date-range "
                    "duplicate detection will be skipped for this claim."
                )

        passed = len(missing) == 0
        elapsed = round((time.monotonic() - start) * 1000, 2)
        result = ReceiptCheckResult(passed=passed, missing_documents=missing, notes=notes)

        logger.info(
            "TOOL receipt_checker | elapsed_ms=%.1f | passed=%s | missing=%s",
            elapsed,
            passed,
            missing or "none",
        )
        return result

    def _tool_fn(self, claim_json: str) -> str:
        import json
        claim = TravelClaim.model_validate(json.loads(claim_json))
        result = self.run(claim)
        if result.passed:
            return "Receipt check PASSED – all required documents are present."
        return (
            f"Receipt check FAILED – missing: {', '.join(result.missing_documents)}.\n"
            + "\n".join(result.notes)
        )

    def as_langchain_tool(self) -> StructuredTool:
        return StructuredTool(
            name="receipt_checker",
            description=(
                "Checks whether the claim has all required receipt and invoice documents. "
                "Returns PASSED or FAILED with details of any missing items. "
                "A FAILED result forces the claim to manual review."
            ),
            args_schema=ReceiptCheckerInput,
            func=self._tool_fn,
        )
