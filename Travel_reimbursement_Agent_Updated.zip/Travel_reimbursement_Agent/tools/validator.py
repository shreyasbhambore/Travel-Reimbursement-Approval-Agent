"""
Tool 6 – Output Validator

The final gate in the pipeline, executed *after* the LLM has produced its
decision. Responsibilities:

1. **Arithmetic guard**: compare the LLM's `approved_amount` / `deduction`
   against the values deterministically computed by `LimitCheckerTool`. If
   they disagree by more than `LLM_AMOUNT_MISMATCH_TOLERANCE`, override the
   LLM's figures silently and record a `ValidationIssue`. LLMs should never
   be the authoritative source of monetary arithmetic in a finance workflow.

2. **manual_review override**: if any of the mandatory-review triggers
   (missing docs, duplicate, unknown category, flight-class violation,
   low-confidence retrieval, or LLM confidence below threshold) are present,
   force `manual_review=True` even if the LLM said False.

3. **decision label consistency**: reconcile `decision` with the actual
   deduction (e.g. if deduction==0 but LLM wrote "Partially Approved",
   upgrade to "Approved").

4. **Schema conformance**: return the final `ClaimDecision` with all required
   fields populated -- the API layer just writes this straight to the
   response.
"""
from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List

from logging_config import get_logger
from schemas import (
    ApprovalCheckResult,
    ClaimDecision,
    DecisionLabel,
    DuplicateCheckResult,
    LimitCheckResult,
    LLMDecision,
    ReceiptCheckResult,
    TravelClaim,
    ValidationIssue,
)

logger = get_logger(__name__)


class ValidatorTool:
    """Stateless; holds no per-instance state beyond the settings reference."""

    def run(
        self,
        *,
        claim: TravelClaim,
        llm_decision: LLMDecision,
        receipt_result: ReceiptCheckResult,
        limit_result: LimitCheckResult,
        approval_result: ApprovalCheckResult,
        duplicate_result: DuplicateCheckResult,
        policy_low_confidence: bool,
        model_name: str,
        execution_start: float,
        extra_context: Dict[str, Any] | None = None,
    ) -> ClaimDecision:
        start_validate = time.monotonic()
        issues: List[ValidationIssue] = []
        settings_tol = _get_tolerance()

        # ── 1. Arithmetic guard ──────────────────────────────────────────
        deterministic_capped = limit_result.capped_amount
        deterministic_deduction = limit_result.total_deduction

        approved_amount = llm_decision.approved_amount
        deduction = llm_decision.deduction

        if abs(deduction - deterministic_deduction) > settings_tol:
            issues.append(
                ValidationIssue(
                    field="deduction",
                    issue=(
                        f"LLM proposed deduction ₹{deduction:,.2f} differs from "
                        f"deterministic calculation ₹{deterministic_deduction:,.2f} by "
                        f"₹{abs(deduction - deterministic_deduction):,.2f}. "
                        "Deterministic value applied."
                    ),
                    corrected=True,
                )
            )
            deduction = deterministic_deduction
            logger.warning(
                "VALIDATOR: overriding LLM deduction (%.2f → %.2f)", llm_decision.deduction, deduction
            )

        if abs(approved_amount - deterministic_capped) > settings_tol:
            issues.append(
                ValidationIssue(
                    field="approved_amount",
                    issue=(
                        f"LLM proposed approved_amount ₹{approved_amount:,.2f} differs from "
                        f"deterministic capped amount ₹{deterministic_capped:,.2f}. "
                        "Deterministic value applied."
                    ),
                    corrected=True,
                )
            )
            approved_amount = deterministic_capped
            logger.warning(
                "VALIDATOR: overriding LLM approved_amount (%.2f → %.2f)",
                llm_decision.approved_amount,
                approved_amount,
            )

        # ── 2. manual_review override triggers ───────────────────────────
        manual_review = llm_decision.manual_review
        manual_review_triggers: List[str] = []

        if not receipt_result.passed:
            manual_review = True
            manual_review_triggers.append("missing_documents")

        if duplicate_result.is_duplicate:
            manual_review = True
            manual_review_triggers.append(f"duplicate_suspected({duplicate_result.match_type})")

        if limit_result.unknown_categories:
            manual_review = True
            manual_review_triggers.append(f"unknown_categories({limit_result.unknown_categories})")

        if limit_result.flight_class_violation:
            manual_review = True
            manual_review_triggers.append("flight_class_violation")

        if policy_low_confidence:
            manual_review = True
            manual_review_triggers.append("low_policy_retrieval_confidence")

        from config import get_settings

        if llm_decision.confidence < get_settings().MIN_CONFIDENCE_FOR_AUTO_DECISION:
            manual_review = True
            manual_review_triggers.append(
                f"llm_confidence_below_threshold({llm_decision.confidence:.2f})"
            )

        if manual_review_triggers:
            logger.info("VALIDATOR: manual_review=True | triggers=%s", manual_review_triggers)

        # ── 3. Decision label consistency ────────────────────────────────
        decision = llm_decision.decision
        if deduction == 0 and decision == DecisionLabel.PARTIALLY_APPROVED:
            decision = DecisionLabel.APPROVED
            issues.append(
                ValidationIssue(
                    field="decision",
                    issue="LLM said 'Partially Approved' but deduction is ₹0; upgraded to 'Approved'.",
                    corrected=True,
                )
            )
        elif deduction > 0 and decision == DecisionLabel.APPROVED:
            decision = DecisionLabel.PARTIALLY_APPROVED
            issues.append(
                ValidationIssue(
                    field="decision",
                    issue=f"LLM said 'Approved' but deduction is ₹{deduction:,.2f}; "
                    "changed to 'Partially Approved'.",
                    corrected=True,
                )
            )
        if manual_review and decision not in (DecisionLabel.MANUAL_REVIEW, DecisionLabel.REJECTED):
            # Don't override the decision label when manual_review=True; Finance reviewers need
            # to see the *original* AI conclusion plus the flag indicating their review is needed,
            # not a masked "Manual Review" label that hides the underlying recommendation.
            pass

        # ── 4. Build the audit trail ──────────────────────────────────────
        audit_trail: List[str] = [
            "Retrieved policy",
            "Validated receipts",
            "Applied limits",
            "Checked duplicates",
            "Generated decision",
        ]
        if issues:
            audit_trail.append(f"Validator corrected {len(issues)} field(s)")
        if manual_review_triggers:
            audit_trail.append(f"Flagged for manual review: {', '.join(manual_review_triggers)}")

        # ── 5. Assemble ClaimDecision ────────────────────────────────────
        execution_time_ms = round((time.monotonic() - execution_start) * 1000, 2)
        validate_ms = round((time.monotonic() - start_validate) * 1000, 2)
        logger.info(
            "VALIDATOR | decision=%s | approved=₹%.2f | deduction=₹%.2f | "
            "manual_review=%s | validation_ms=%.1f | total_ms=%.1f",
            decision.value,
            approved_amount,
            deduction,
            manual_review,
            validate_ms,
            execution_time_ms,
        )

        return ClaimDecision(
            claim_id=f"CLM-{uuid.uuid4().hex[:8].upper()}",
            trip_id=claim.trip_id or "TRIP-UNKNOWN",
            employee_id=claim.employee_id,
            employee_name=claim.name,
            decision=decision,
            approved_amount=approved_amount,
            deduction=deduction,
            manual_review=manual_review,
            policy_reference=llm_decision.policy_reference,
            confidence=llm_decision.confidence,
            missing_documents=receipt_result.missing_documents,
            reason=llm_decision.reason,
            approval_level=approval_result.approval_level,
            approver_role=approval_result.approver_role,
            duplicate_suspected=duplicate_result.is_duplicate,
            total_claimed_amount=claim.total_claimed_amount,
            validation_issues=issues,
            audit_trail=audit_trail,
            evaluated_at=datetime.now(timezone.utc),
            execution_time_ms=execution_time_ms,
            model_used=model_name,
        )


def _get_tolerance() -> float:
    from config import get_settings

    return get_settings().LLM_AMOUNT_MISMATCH_TOLERANCE
