"""
Logging configuration.

Sets up two log surfaces:

1. **Application log** (`logs/app.log`, rotating, human-readable) -- every
   node execution, tool call, retrieval, and error in the pipeline, at INFO
   level by default (DEBUG for RAG query internals).

2. **Decision audit log** (`logs/decisions.log`, JSON-lines) -- one compact
   JSON record per completed `/evaluate-claim` call, written by
   `log_decision_record()`. This is the file to tail for a running audit
   trail of every decision the agent has made, independent of the verbose
   application log.

Call `configure_logging()` once at process startup (done in `app.py`).
`get_logger(__name__)` elsewhere returns a standard `logging.Logger` that
propagates to the handlers configured here.
"""
from __future__ import annotations

import json
import logging
import logging.handlers
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

_CONFIGURED = False


def configure_logging(log_level: str | None = None) -> None:
    """Idempotent: safe to call multiple times (e.g. once from app.py, once
    from a test fixture) -- only configures handlers on the first call."""
    global _CONFIGURED
    if _CONFIGURED:
        return

    from config import get_settings

    settings = get_settings()
    level = getattr(logging, (log_level or settings.LOG_LEVEL).upper(), logging.INFO)

    settings.LOGS_DIR.mkdir(parents=True, exist_ok=True)

    root = logging.getLogger()
    root.setLevel(level)

    fmt = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Console handler
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(fmt)
    console.setLevel(level)
    root.addHandler(console)

    # Rotating application-log file handler (5 MB x 5 backups)
    file_handler = logging.handlers.RotatingFileHandler(
        settings.LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    file_handler.setFormatter(fmt)
    file_handler.setLevel(level)
    root.addHandler(file_handler)

    # Quiet down noisy third-party loggers.
    for noisy in ("httpx", "httpcore", "urllib3", "sentence_transformers", "faiss"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    _CONFIGURED = True
    logging.getLogger(__name__).info(
        "Logging configured | level=%s | app_log=%s | decision_log=%s",
        logging.getLevelName(level),
        settings.LOG_FILE,
        settings.DECISION_LOG_FILE,
    )


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


def log_decision_record(record: Dict[str, Any]) -> None:
    """Append one JSON-line audit record to `logs/decisions.log`.

    Never raises: a failure to write the audit log must not take down the
    API response. Errors are logged to the application log instead.
    """
    from config import get_settings

    settings = get_settings()
    payload = {"timestamp": datetime.now(timezone.utc).isoformat(), **record}
    try:
        settings.LOGS_DIR.mkdir(parents=True, exist_ok=True)
        with open(settings.DECISION_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(payload, default=str) + "\n")
    except Exception as exc:  # pragma: no cover - defensive only
        get_logger(__name__).error("Failed to write decision audit record: %s", exc)
