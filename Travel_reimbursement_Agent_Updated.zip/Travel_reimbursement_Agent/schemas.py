"""
Pydantic schemas shared across the entire application.

This module is the single source of truth for every data shape that crosses
a boundary in the system: the inbound API request, the outbound API response,
every LangGraph tool result, the LLM's structured output, and the health/error
envelopes. Keeping them all in one place means every layer (app.py, agent/,
tools/, rag/) imports from here instead of redefining shapes locally, which is
what keeps the LangGraph state, the tool signatures, and the FastAPI response
models all in sync.

Pydantic v2 throughout.
"""
from __future__ import annotations

from datetime import date, datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, computed_field, field_validator


# ─────────────────────────────────────────────────────────────────────────────
# Enums
# ─────────────────────────────────────────────────────────────────────────────

class TripType(str, Enum):
    DOMESTIC = "Domestic"
    INTERNATIONAL = "International"


class FlightClass(str, Enum):
    ECONOMY = "Economy"
    PREMIUM_ECONOMY = "Premium Economy"
    BUSINESS = "Business"
    FIRST = "First"


class DecisionLabel(str, Enum):
    APPROVED = "Approved"
    PARTIALLY_APPROVED = "Partially Approved"
    REJECTED = "Rejected"
    MANUAL_REVIEW = "Manual Review"


class ApprovalLevel(str, Enum):
    AUTO = "Auto"
    MANAGER = "Manager"
    FINANCE_HEAD = "FinanceHead"


# ─────────────────────────────────────────────────────────────────────────────
# Inbound: TravelClaim (the /evaluate-claim request body)
# ─────────────────────────────────────────────────────────────────────────────

class TravelClaim(BaseModel):
    """A travel reimbursement claim submitted by an employee.

    Only `employee_id`, `name`, `trip_type`, `hotel`, `flight`, `meal`, `taxi`,
    and `receipt_uploaded` are required (this matches the assignment brief's
    minimal example payload). Every other field is optional and enriches the
    quality of duplicate-detection, receipt-validation, and approval-routing
    decisions when supplied.
    """

    # ── Required (assignment brief minimal payload) ─────────────────────
    employee_id: str = Field(..., min_length=1, description="Unique employee identifier, e.g. 'EMP001'.")
    name: str = Field(..., min_length=1, description="Employee full name.")
    trip_type: TripType = Field(..., description="'Domestic' or 'International'.")
    hotel: float = Field(..., ge=0, description="Total hotel expense claimed, in INR.")
    flight: float = Field(..., ge=0, description="Total flight expense claimed, in INR.")
    meal: float = Field(..., ge=0, description="Total meal expense claimed, in INR.")
    taxi: float = Field(..., ge=0, description="Total taxi/local-transport expense claimed, in INR.")
    receipt_uploaded: bool = Field(..., description="Whether a receipt/proof of payment was uploaded.")

    # ── Optional enrichment fields ───────────────────────────────────────
    trip_id: Optional[str] = Field(default=None, description="Trip identifier, if the claim is tied to a pre-approved trip.")
    invoice_number: Optional[str] = Field(default=None, description="Invoice/receipt number, used for duplicate detection.")
    destination: Optional[str] = Field(default=None, description="City/country travelled to.")
    department: Optional[str] = Field(default=None, description="Employee's department, for reporting.")
    travel_start_date: Optional[date] = Field(default=None, description="Trip start date (ISO 8601).")
    travel_end_date: Optional[date] = Field(default=None, description="Trip end date (ISO 8601).")

    flight_class: FlightClass = Field(default=FlightClass.ECONOMY, description="Cabin class flown.")
    flight_class_pre_approved: bool = Field(
        default=False, description="Whether Business/First class was pre-approved by Finance Head."
    )

    hotel_invoice_uploaded: Optional[bool] = Field(
        default=None, description="Whether a dedicated hotel invoice was uploaded (defaults to receipt_uploaded logic if omitted)."
    )
    flight_invoice_uploaded: Optional[bool] = Field(
        default=None, description="Whether a dedicated flight invoice/ticket was uploaded."
    )

    other_expenses: Optional[Dict[str, float]] = Field(
        default=None, description="Any additional expense categories not covered by hotel/flight/meal/taxi, e.g. {'client_entertainment': 3000}."
    )

    @field_validator("other_expenses")
    @classmethod
    def _validate_other_expenses(cls, v: Optional[Dict[str, float]]) -> Optional[Dict[str, float]]:
        if v is None:
            return v
        for k, amt in v.items():
            if amt < 0:
                raise ValueError(f"other_expenses[{k!r}] must be non-negative, got {amt}")
        return v

    @computed_field  # type: ignore[misc]
    @property
    def total_claimed_amount(self) -> float:
        base = self.hotel + self.flight + self.meal + self.taxi
        extra = sum(self.other_expenses.values()) if self.other_expenses else 0.0
        return round(base + extra, 2)

    model_config = {
        "json_schema_extra": {
            "example": {
                "employee_id": "EMP001",
                "name": "John Doe",
                "trip_type": "Domestic",
                "hotel": 6200,
                "flight": 14000,
                "meal": 900,
                "taxi": 800,
                "receipt_uploaded": True,
            }
        }
    }


# ─────────────────────────────────────────────────────────────────────────────
# RAG / Policy retrieval
# ─────────────────────────────────────────────────────────────────────────────

class PolicyChunk(BaseModel):
    content: str = Field(..., description="Retrieved policy text chunk.")
    source: str = Field(default="travel_policy.md", description="Source document filename.")
    score: float = Field(..., description="Relevance score, higher is better, in [0, 1] where possible.")


class PolicyRetrievalResult(BaseModel):
    chunks: List[PolicyChunk] = Field(default_factory=list)
    query: str = Field(..., description="The natural-language query issued to the retriever.")
    top_score: float = Field(default=0.0)
    low_confidence: bool = Field(
        default=False, description="True when top_score is below the configured relevance threshold."
    )

    @computed_field  # type: ignore[misc]
    @property
    def combined_text(self) -> str:
        """All retrieved chunk contents joined for direct inclusion in an LLM prompt."""
        if not self.chunks:
            return "No relevant policy sections were retrieved."
        parts = [f"[Section {i} | relevance {c.score:.3f}]\n{c.content}" for i, c in enumerate(self.chunks, 1)]
        return "\n\n".join(parts)


# ─────────────────────────────────────────────────────────────────────────────
# Tool 2: Receipt Checker
# ─────────────────────────────────────────────────────────────────────────────

class ReceiptCheckResult(BaseModel):
    passed: bool
    missing_documents: List[str] = Field(default_factory=list)
    notes: List[str] = Field(default_factory=list)


# ─────────────────────────────────────────────────────────────────────────────
# Tool 3: Expense Limit Checker
# ─────────────────────────────────────────────────────────────────────────────

class LimitDeduction(BaseModel):
    category: str
    claimed: float
    limit: Optional[float] = None
    deduction: float = 0.0
    within_limit: bool = True
    note: str = ""


class LimitCheckResult(BaseModel):
    trip_type: TripType
    deductions: List[LimitDeduction] = Field(default_factory=list)
    total_deduction: float = 0.0
    base_claimed_amount: float = 0.0
    capped_amount: float = 0.0
    unknown_categories: List[str] = Field(default_factory=list)
    unknown_amount: float = 0.0
    flight_class_violation: bool = False
    flight_class_note: Optional[str] = None


# ─────────────────────────────────────────────────────────────────────────────
# Tool 4: Approval Matrix Checker
# ─────────────────────────────────────────────────────────────────────────────

class ApprovalCheckResult(BaseModel):
    approval_level: ApprovalLevel
    approver_role: Optional[str] = None
    threshold_basis_amount: float = 0.0
    escalated_for_policy_reason: Optional[str] = None
    rationale: str = ""


# ─────────────────────────────────────────────────────────────────────────────
# Tool 5: Duplicate Checker
# ─────────────────────────────────────────────────────────────────────────────

class DuplicateCheckResult(BaseModel):
    is_duplicate: bool
    match_type: Optional[str] = None
    matched_trip_id: Optional[str] = None
    confidence: float = 0.0
    notes: str = ""


# ─────────────────────────────────────────────────────────────────────────────
# LLM structured output (Tool: LLM Decision node)
# ─────────────────────────────────────────────────────────────────────────────

class LLMDecision(BaseModel):
    """Structured output requested from the Groq LLM via
    `ChatGroq.with_structured_output(LLMDecision)`. Field descriptions double
    as guidance embedded in the generated JSON schema shown to the model."""

    decision: DecisionLabel = Field(..., description="One of Approved | Partially Approved | Rejected | Manual Review.")
    approved_amount: float = Field(..., ge=0, description="Proposed reimbursable amount in INR after deductions.")
    deduction: float = Field(..., ge=0, description="Proposed total amount deducted, in INR.")
    manual_review: bool = Field(..., description="Whether a human must review this claim before disbursement.")
    policy_reference: str = Field(..., description="Concise citation of the governing policy clause(s).")
    confidence: float = Field(..., ge=0, le=1, description="Model's confidence in this decision, 0.0-1.0.")
    missing_documents: List[str] = Field(default_factory=list)
    reason: str = Field(..., description="1-3 sentence plain-English explanation for the employee.")


# ─────────────────────────────────────────────────────────────────────────────
# Output Validator
# ─────────────────────────────────────────────────────────────────────────────

class ValidationIssue(BaseModel):
    field: str
    issue: str
    corrected: bool = False


# ─────────────────────────────────────────────────────────────────────────────
# Outbound: ClaimDecision (the /evaluate-claim response body)
# ─────────────────────────────────────────────────────────────────────────────

class ClaimDecision(BaseModel):
    claim_id: str
    trip_id: str
    employee_id: str
    employee_name: str

    decision: DecisionLabel
    approved_amount: float
    deduction: float
    manual_review: bool
    policy_reference: str
    confidence: float
    missing_documents: List[str] = Field(default_factory=list)
    reason: str

    approval_level: ApprovalLevel
    approver_role: Optional[str] = None
    duplicate_suspected: bool = False
    total_claimed_amount: float

    validation_issues: List[ValidationIssue] = Field(default_factory=list)

    audit_trail: List[str] = Field(
        default_factory=list,
        description="Ordered list of pipeline steps executed to reach this decision.",
    )

    evaluated_at: datetime
    execution_time_ms: float
    model_used: str

    model_config = {
        "json_schema_extra": {
            "example": {
                "claim_id": "CLM-A1B2C3D4",
                "trip_id": "TRIP-UNKNOWN",
                "employee_id": "EMP001",
                "employee_name": "John Doe",
                "decision": "Partially Approved",
                "approved_amount": 20700.0,
                "deduction": 1200.0,
                "manual_review": False,
                "policy_reference": "Section 3: Hotel cap ₹5,000/night for Domestic trips.",
                "confidence": 0.96,
                "missing_documents": [],
                "reason": "Hotel expense exceeded the domestic cap; ₹1,200 deducted.",
                "approval_level": "Manager",
                "approver_role": "Direct Manager",
                "duplicate_suspected": False,
                "total_claimed_amount": 21900.0,
                "validation_issues": [],
                "audit_trail": [
                    "Retrieved policy",
                    "Validated receipts",
                    "Applied limits",
                    "Checked duplicates",
                    "Generated decision",
                ],
                "evaluated_at": "2026-07-01T10:15:00Z",
                "execution_time_ms": 452.3,
                "model_used": "openai/gpt-oss-120b",
            }
        }
    }


# ─────────────────────────────────────────────────────────────────────────────
# Operational envelopes
# ─────────────────────────────────────────────────────────────────────────────

class HealthStatus(BaseModel):
    status: str = Field(..., description="'ok' or 'degraded'.")
    version: str
    groq_configured: bool
    vector_store_ready: bool
    details: Dict[str, Any] = Field(default_factory=dict)


class ErrorResponse(BaseModel):
    detail: str
    error_code: Optional[str] = None
