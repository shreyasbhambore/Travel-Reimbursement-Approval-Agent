"""LangGraph agent: state, prompts, node functions, and graph builder."""
