"""
LLM prompt templates for the Travel Reimbursement Approval Agent.

All prompts live here so they can be reviewed, versioned, and A/B-tested
independently of the surrounding code. Every template uses Python f-strings
(rather than LangChain PromptTemplate objects) to keep them readable and free
of any hidden escaping behaviour -- the final string is assembled in nodes.py
before being passed to the LLM.
"""
from __future__ import annotations


SYSTEM_PROMPT = """\
You are the Travel Reimbursement Approval Agent for an enterprise finance team.
Your role is to review travel reimbursement claims against company policy and produce
a structured, accurate, and fair decision.

KEY RULES:
1. You are provided with pre-computed tool outputs (receipt check, limit check, approval
   routing, duplicate check). Trust these outputs -- they are deterministic and correct.
   Do NOT recompute amounts, limits, or approval levels yourself; your job is to synthesise
   the tool outputs into a coherent decision narrative and select the right decision label.

2. The `approved_amount` and `deduction` you produce are proposals. A downstream validator
   will override them with the deterministically computed values if they disagree by more
   than ₹1.00, so approximate rounding is fine, but never fabricate figures.

3. `manual_review` must be True if ANY of the following is true:
   - Receipt or invoice documents are missing
   - A duplicate claim is suspected
   - An unknown expense category is present
   - A flight-class violation is flagged
   - Policy retrieval confidence is low
   - Your own confidence is below 0.6
   Otherwise, set it to False.

4. `confidence` should reflect how clearly the policy covers this claim. 1.0 = perfectly
   clear policy match with no anomalies. 0.5 = ambiguous policy or unusual claim pattern.
   Below 0.6 triggers automatic manual review.

5. `policy_reference` must be a concise, human-readable citation of the specific policy
   clause driving your decision (e.g. "Section 3: Hotel cap ₹5,000/night for Domestic trips").

6. Respond ONLY in the JSON schema requested. Do not include any preamble, markdown code
   fences, or commentary outside the JSON object.
"""


def build_decision_prompt(
    claim_summary: str,
    policy_context: str,
    receipt_summary: str,
    limit_summary: str,
    approval_summary: str,
    duplicate_summary: str,
) -> str:
    """Build the user-turn prompt that packages all tool outputs for the LLM."""
    return f"""\
## CLAIM UNDER REVIEW
{claim_summary}

## POLICY CONTEXT (retrieved from FAISS vector store)
{policy_context}

## TOOL RESULTS

### Receipt / Document Check
{receipt_summary}

### Expense Limit Check
{limit_summary}

### Approval Matrix Routing
{approval_summary}

### Duplicate Check
{duplicate_summary}

## TASK
Based on the above tool results and policy context, produce a JSON decision object with
exactly these fields (and no others):

{{
  "decision": "<Approved | Partially Approved | Rejected | Manual Review>",
  "approved_amount": <float, ₹ approved after deductions>,
  "deduction": <float, total ₹ deducted>,
  "manual_review": <true | false>,
  "policy_reference": "<concise citation of the governing policy clause(s)>",
  "confidence": <float 0.0-1.0>,
  "missing_documents": [<list of missing doc names, empty if none>],
  "reason": "<1-3 sentence plain-English explanation of the decision for the employee>"
}}

Return ONLY the JSON object. No preamble, no markdown fences.
"""


def format_claim_summary(claim) -> str:
    """Compact, human-readable summary of the claim for the prompt."""
    parts = [
        f"Employee: {claim.name} ({claim.employee_id})",
        f"Trip type: {claim.trip_type.value}",
    ]
    if claim.destination:
        parts.append(f"Destination: {claim.destination}")
    if claim.travel_start_date and claim.travel_end_date:
        parts.append(f"Dates: {claim.travel_start_date} – {claim.travel_end_date}")

    parts.append(f"Hotel:  ₹{claim.hotel:,.2f}")
    parts.append(f"Flight: ₹{claim.flight:,.2f} ({claim.flight_class.value})")
    parts.append(f"Meal:   ₹{claim.meal:,.2f}")
    parts.append(f"Taxi:   ₹{claim.taxi:,.2f}")

    if claim.other_expenses:
        for cat, amt in claim.other_expenses.items():
            parts.append(f"Other ({cat}): ₹{amt:,.2f}")

    parts.append(f"Total claimed: ₹{claim.total_claimed_amount:,.2f}")
    parts.append(f"Receipt uploaded: {claim.receipt_uploaded}")

    if claim.invoice_number:
        parts.append(f"Invoice number: {claim.invoice_number}")

    return "\n".join(parts)
