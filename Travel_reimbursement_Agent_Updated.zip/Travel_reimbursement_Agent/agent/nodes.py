"""
LangGraph workflow nodes.

Each function accepts the current `AgentState` dict and returns a **partial
dict** with only the keys it writes. LangGraph merges this update onto the
state before calling the next node. The functions are pure state-transformers
-- all side effects (logging, ledger writes) live in their respective tool
classes or logging_config.py.

Dependency injection: every node function that needs a service (retriever,
tools, LLM) receives it via a partially-applied `functools.partial` wrapper
rather than using module-level globals. This keeps the node functions pure and
unit-testable with simple mock objects. The `build_nodes()` factory in this
module wires everything together; it is called once at startup from
`agent/graph.py`.
"""
from __future__ import annotations

import json
import time
from typing import Any, Callable, Dict
from langchain_core.output_parsers import JsonOutputParser

from langchain_groq import ChatGroq
from langchain_core.messages import HumanMessage, SystemMessage

from agent.prompts import (
    SYSTEM_PROMPT,
    build_decision_prompt,
    format_claim_summary,
)
from agent.state import AgentState
from config import get_settings
from ledger import ClaimsLedger, LedgerEntry
from logging_config import get_logger
from schemas import LLMDecision
from tools.approval_checker import ApprovalCheckerTool
from tools.duplicate_checker import DuplicateCheckerTool
from tools.limit_checker import LimitCheckerTool
from tools.policy_lookup import PolicyLookupTool
from tools.receipt_checker import ReceiptCheckerTool
from tools.validator import ValidatorTool

logger = get_logger(__name__)

# ── Typed helpers ─────────────────────────────────────────────────────────────
NodeFn = Callable[[AgentState], Dict[str, Any]]


# ── Individual node implementations ──────────────────────────────────────────

def node_claim_intake(state: AgentState) -> Dict[str, Any]:
    """No-op pass-through that just logs the claim arrival. Exists as an
    explicit node so the graph topology matches the specification diagram and
    can be visualised cleanly."""
    claim = state["claim"]
    if claim is None:
        return {"error": "No claim in state; cannot proceed."}
    logger.info(
        "NODE claim_intake | employee=%s | trip=%s | total=₹%.2f",
        claim.employee_id,
        claim.trip_type.value,
        claim.total_claimed_amount,
    )
    return {}  # state unchanged; just logged


def _build_policy_node(policy_tool: PolicyLookupTool) -> NodeFn:
    def node_retrieve_policy(state: AgentState) -> Dict[str, Any]:
        claim = state["claim"]
        if claim is None:
            return {"error": "Claim missing in policy retrieval node."}

        query = (
            f"{claim.trip_type.value} trip hotel reimbursement limit "
            f"meal allowance taxi flight class approval rules documentation requirements"
        )
        result = policy_tool.run(query)
        logger.info(
            "NODE retrieve_policy | chunks=%d | top_score=%.4f | low_confidence=%s",
            len(result.chunks),
            result.top_score,
            result.low_confidence,
        )
        return {"policy_result": result}

    return node_retrieve_policy


def _build_receipt_node(receipt_tool: ReceiptCheckerTool) -> NodeFn:
    def node_receipt_validation(state: AgentState) -> Dict[str, Any]:
        claim = state["claim"]
        if claim is None:
            return {"error": "Claim missing in receipt validation node."}
        result = receipt_tool.run(claim)
        return {"receipt_result": result}

    return node_receipt_validation


def _build_limit_node(limit_tool: LimitCheckerTool) -> NodeFn:
    def node_expense_limit(state: AgentState) -> Dict[str, Any]:
        claim = state["claim"]
        if claim is None:
            return {"error": "Claim missing in expense limit node."}
        result = limit_tool.run(claim)
        return {"limit_result": result}

    return node_expense_limit


def _build_approval_node(approval_tool: ApprovalCheckerTool) -> NodeFn:
    def node_approval_matrix(state: AgentState) -> Dict[str, Any]:
        claim = state["claim"]
        limit_result = state.get("limit_result")
        if claim is None or limit_result is None:
            return {"error": "Missing claim or limit_result in approval node."}
        result = approval_tool.run(claim, limit_result)
        return {"approval_result": result}

    return node_approval_matrix


def _build_duplicate_node(dup_tool: DuplicateCheckerTool) -> NodeFn:
    def node_duplicate_check(state: AgentState) -> Dict[str, Any]:
        claim = state["claim"]
        if claim is None:
            return {"error": "Claim missing in duplicate check node."}
        result = dup_tool.run(claim)
        return {"duplicate_result": result}

    return node_duplicate_check


def _build_llm_node(llm: ChatGroq, model_name: str) -> NodeFn:
    """Call the Groq LLM with the assembled context and parse its
    structured output into an `LLMDecision`."""

    def node_llm_decision(state: AgentState) -> Dict[str, Any]:
        claim = state["claim"]
        policy_result = state.get("policy_result")
        receipt_result = state.get("receipt_result")
        limit_result = state.get("limit_result")
        approval_result = state.get("approval_result")
        duplicate_result = state.get("duplicate_result")

        if any(v is None for v in [claim, receipt_result, limit_result, approval_result, duplicate_result]):
            return {"error": "One or more required tool results missing before LLM node."}

        # Build prompt components
        claim_summary = format_claim_summary(claim)

        policy_context = (
            policy_result.combined_text
            if policy_result and policy_result.chunks
            else "No policy sections retrieved."
        )

        receipt_lines = [
            f"Passed: {receipt_result.passed}",
            f"Missing documents: {receipt_result.missing_documents or 'none'}",
        ] + (receipt_result.notes or [])

        limit_deductions_text = "\n".join(
            f"  {d.category}: {d.note}" for d in limit_result.deductions
        )
        limit_lines = [
            f"Trip type: {limit_result.trip_type.value}",
            f"Base claimed: ₹{limit_result.base_claimed_amount:,.2f}",
            f"Total deduction: ₹{limit_result.total_deduction:,.2f}",
            f"Capped amount: ₹{limit_result.capped_amount:,.2f}",
            f"Per-category:\n{limit_deductions_text}",
        ]
        if limit_result.unknown_categories:
            limit_lines.append(
                f"Unknown categories: {limit_result.unknown_categories} "
                f"(₹{limit_result.unknown_amount:,.2f}) – manual review required."
            )
        if limit_result.flight_class_violation:
            limit_lines.append(f"Flight class violation: {limit_result.flight_class_note}")

        approval_lines = [
            f"Approval tier: {approval_result.approval_level.value}",
            f"Approver role: {approval_result.approver_role or 'none'}",
            f"Rationale: {approval_result.rationale}",
        ]

        dup_lines = [
            f"Duplicate suspected: {duplicate_result.is_duplicate}",
        ]
        if duplicate_result.is_duplicate:
            dup_lines.append(f"Match type: {duplicate_result.match_type}")
            dup_lines.append(f"Confidence: {duplicate_result.confidence:.2f}")
            dup_lines.append(f"Notes: {duplicate_result.notes}")

        user_prompt = build_decision_prompt(
            claim_summary=claim_summary,
            policy_context=policy_context,
            receipt_summary="\n".join(receipt_lines),
            limit_summary="\n".join(limit_lines),
            approval_summary="\n".join(approval_lines),
            duplicate_summary="\n".join(dup_lines),
        )

        messages = [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(content=user_prompt),
        ]

        settings = get_settings()
        start = time.monotonic()
        logger.info("NODE llm_decision | invoking model=%s", model_name)

        raw_content: str | None = None
        for attempt in range(settings.GROQ_MAX_RETRIES + 1):
            try:
                # Use structured output via JSON schema for constrained decoding
                # (supported on openai/gpt-oss-120b and openai/gpt-oss-20b with strict=True).
                parser = JsonOutputParser(pydantic_object=LLMDecision)

                response = llm.invoke(messages)

                parsed_dict = parser.parse(response.content)

                parsed = LLMDecision.model_validate(parsed_dict)
                elapsed = round((time.monotonic() - start) * 1000, 2)
                logger.info(
                    "NODE llm_decision | attempt=%d | elapsed_ms=%.1f | "
                    "decision=%s | confidence=%.2f",
                    attempt + 1,
                    elapsed,
                    parsed.decision.value,
                    parsed.confidence,
                )
                return {"llm_decision": parsed}
            except Exception as exc:
                if attempt == settings.GROQ_MAX_RETRIES:
                    logger.error(
                        "NODE llm_decision | all attempts exhausted | error=%s",
                        exc,
                        exc_info=True,
                    )
                    # Construct a safe fallback so the graph can still write a
                    # human-reviewable record rather than returning a 500.
                    from schemas import DecisionLabel
                    fallback = LLMDecision(
                        decision=DecisionLabel.MANUAL_REVIEW,
                        approved_amount=0.0,
                        deduction=0.0,
                        manual_review=True,
                        policy_reference="LLM evaluation failed; refer to Finance for manual processing.",
                        confidence=0.0,
                        missing_documents=[],
                        reason=(
                            f"The automated decision engine encountered an error "
                            f"(attempt {settings.GROQ_MAX_RETRIES + 1}): {exc}. "
                            "This claim requires manual review."
                        ),
                    )
                    return {"llm_decision": fallback, "error": str(exc)}
                logger.warning(
                    "NODE llm_decision | attempt=%d failed (%s); retrying", attempt + 1, exc
                )

        # Unreachable, but mypy wants a return here.
        return {"error": "LLM node exited retry loop without returning."}

    return node_llm_decision


def _build_validation_node(
    validator: ValidatorTool,
    ledger: ClaimsLedger,
    model_name: str,
) -> NodeFn:
    def node_output_validation(state: AgentState) -> Dict[str, Any]:
        claim = state["claim"]
        llm_decision = state.get("llm_decision")
        receipt_result = state.get("receipt_result")
        limit_result = state.get("limit_result")
        approval_result = state.get("approval_result")
        duplicate_result = state.get("duplicate_result")
        policy_result = state.get("policy_result")

        if any(
            v is None
            for v in [
                claim,
                llm_decision,
                receipt_result,
                limit_result,
                approval_result,
                duplicate_result,
            ]
        ):
            return {"error": "Required state missing in validation node."}

        policy_low_confidence = policy_result.low_confidence if policy_result else True

        final = validator.run(
            claim=claim,
            llm_decision=llm_decision,
            receipt_result=receipt_result,
            limit_result=limit_result,
            approval_result=approval_result,
            duplicate_result=duplicate_result,
            policy_low_confidence=policy_low_confidence,
            model_name=model_name,
            execution_start=state["execution_start"],
        )

        # Record in ledger (after final decision so the claim_id is set)
        evaluated_at = final.evaluated_at.isoformat() if final.evaluated_at else ""
        ledger.record(
            LedgerEntry(
                claim_id=final.claim_id,
                trip_id=claim.trip_id or "",
                employee_id=claim.employee_id,
                invoice_number=claim.invoice_number,
                destination=claim.destination,
                travel_start_date=str(claim.travel_start_date) if claim.travel_start_date else None,
                travel_end_date=str(claim.travel_end_date) if claim.travel_end_date else None,
                trip_type=claim.trip_type.value,
                hotel=claim.hotel,
                flight=claim.flight,
                meal=claim.meal,
                taxi=claim.taxi,
                evaluated_at=evaluated_at,
            )
        )
        logger.info(
            "NODE output_validation | claim_id=%s | decision=%s | approved=₹%.2f | "
            "manual_review=%s | total_ms=%.1f",
            final.claim_id,
            final.decision.value,
            final.approved_amount,
            final.manual_review,
            final.execution_time_ms,
        )
        return {"final_decision": final}

    return node_output_validation


# ── Factory ───────────────────────────────────────────────────────────────────

class NodeBundle:
    """All node functions, ready to be added to the StateGraph."""

    def __init__(
        self,
        intake: NodeFn,
        retrieve_policy: NodeFn,
        receipt_validation: NodeFn,
        expense_limit: NodeFn,
        approval_matrix: NodeFn,
        duplicate_check: NodeFn,
        llm_decision: NodeFn,
        output_validation: NodeFn,
    ):
        self.intake = intake
        self.retrieve_policy = retrieve_policy
        self.receipt_validation = receipt_validation
        self.expense_limit = expense_limit
        self.approval_matrix = approval_matrix
        self.duplicate_check = duplicate_check
        self.llm_decision = llm_decision
        self.output_validation = output_validation


def build_nodes(
    policy_tool: PolicyLookupTool,
    receipt_tool: ReceiptCheckerTool,
    limit_tool: LimitCheckerTool,
    approval_tool: ApprovalCheckerTool,
    dup_tool: DuplicateCheckerTool,
    validator: ValidatorTool,
    ledger: ClaimsLedger,
) -> NodeBundle:
    """Wire every node to its dependencies and return the complete bundle.
    Called once at application startup."""
    settings = get_settings()

    llm = ChatGroq(
        model=settings.GROQ_MODEL,
        temperature=settings.GROQ_TEMPERATURE,
        api_key=settings.GROQ_API_KEY,
    )

    return NodeBundle(
        intake=node_claim_intake,
        retrieve_policy=_build_policy_node(policy_tool),
        receipt_validation=_build_receipt_node(receipt_tool),
        expense_limit=_build_limit_node(limit_tool),
        approval_matrix=_build_approval_node(approval_tool),
        duplicate_check=_build_duplicate_node(dup_tool),
        llm_decision=_build_llm_node(llm, settings.GROQ_MODEL),
        output_validation=_build_validation_node(validator, ledger, settings.GROQ_MODEL),
    )
