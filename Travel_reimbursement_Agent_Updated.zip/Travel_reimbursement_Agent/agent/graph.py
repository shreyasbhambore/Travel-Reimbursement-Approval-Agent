"""
LangGraph workflow graph definition.

Constructs, compiles, and returns the CompiledStateGraph that drives the
entire claim-evaluation pipeline.
"""

from __future__ import annotations

from langgraph.graph import END, START, StateGraph

from agent.nodes import NodeBundle
from agent.state import AgentState
from logging_config import get_logger

logger = get_logger(__name__)


def build_graph(nodes: NodeBundle):
    """Build and compile the LangGraph workflow."""

    builder = StateGraph(AgentState)

    # Register nodes
    builder.add_node("claim_intake", nodes.intake)
    builder.add_node("retrieve_policy", nodes.retrieve_policy)
    builder.add_node("receipt_validation", nodes.receipt_validation)
    builder.add_node("expense_limit", nodes.expense_limit)
    builder.add_node("approval_matrix", nodes.approval_matrix)
    builder.add_node("duplicate_check", nodes.duplicate_check)

    # IMPORTANT:
    # Node name must NOT match a state key.
    builder.add_node("generate_decision", nodes.llm_decision)

    builder.add_node("output_validation", nodes.output_validation)

    # Workflow
    builder.add_edge(START, "claim_intake")
    builder.add_edge("claim_intake", "retrieve_policy")
    builder.add_edge("retrieve_policy", "receipt_validation")
    builder.add_edge("receipt_validation", "expense_limit")
    builder.add_edge("expense_limit", "approval_matrix")
    builder.add_edge("approval_matrix", "duplicate_check")
    builder.add_edge("duplicate_check", "generate_decision")
    builder.add_edge("generate_decision", "output_validation")
    builder.add_edge("output_validation", END)

    graph = builder.compile()

    logger.info("LangGraph compiled successfully.")

    return graph