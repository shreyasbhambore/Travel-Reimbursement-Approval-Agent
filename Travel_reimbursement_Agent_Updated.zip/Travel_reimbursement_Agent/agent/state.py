"""
LangGraph workflow state.

A single `TypedDict` that flows through every node of the graph, accumulating
results as the claim progresses through the pipeline. Using a TypedDict (rather
than a Pydantic model) is the LangGraph idiom -- each node returns a *partial
dict* with only the keys it touches; LangGraph merges the partial update onto
the state before calling the next node.

Every field is Optional with a sensible default so nodes that run early in the
graph don't have to care about fields set by later nodes.
"""
from __future__ import annotations

from typing import Optional

from typing_extensions import TypedDict

from schemas import (
    ApprovalCheckResult,
    ClaimDecision,
    DuplicateCheckResult,
    LimitCheckResult,
    LLMDecision,
    PolicyRetrievalResult,
    ReceiptCheckResult,
    TravelClaim,
)


class AgentState(TypedDict):
    # ── Inbound claim ──────────────────────────────────────────────────
    claim: Optional[TravelClaim]

    # ── Per-node results (filled in order by the pipeline nodes) ───────
    policy_result: Optional[PolicyRetrievalResult]
    receipt_result: Optional[ReceiptCheckResult]
    limit_result: Optional[LimitCheckResult]
    approval_result: Optional[ApprovalCheckResult]
    duplicate_result: Optional[DuplicateCheckResult]

    # ── LLM output proposal ────────────────────────────────────────────
    llm_decision: Optional[LLMDecision]

    # ── Final validated output ─────────────────────────────────────────
    final_decision: Optional[ClaimDecision]

    # ── Execution metadata ─────────────────────────────────────────────
    execution_start: float  # time.monotonic() at graph entry
    error: Optional[str]     # set by any node that fails fatally


def initial_state(claim: TravelClaim) -> AgentState:
    """Construct the starting state for a new evaluation run."""
    import time

    return AgentState(
        claim=claim,
        policy_result=None,
        receipt_result=None,
        limit_result=None,
        approval_result=None,
        duplicate_result=None,
        llm_decision=None,
        final_decision=None,
        execution_start=time.monotonic(),
        error=None,
    )
