# Corporate Travel & Expense Reimbursement Policy

**Effective Date:** April 1, 2026
**Applies to:** All full-time and contract employees travelling on approved company business.
**Owner:** Finance & Accounts Department

This document governs how business travel expenses are claimed, validated, and
reimbursed. It is the authoritative source consulted by the Travel Reimbursement
Approval Agent when evaluating a claim. All monetary limits are in Indian Rupees
(INR, ₹) unless stated otherwise.

---

## Section 1: Domestic vs. International Trip Classification

A trip is classified as **Domestic** if both the origin and destination are
within India, and **International** if either the origin or the destination is
outside India.

International trips carry higher reimbursement caps across every category to
account for higher costs of living, currency conversion overheads, and longer
travel durations. Employees must select the correct `trip_type` when filing a
claim; misclassification may result in the claim being routed to manual review.

International trips also require:
- A valid passport and visa copy on file with HR prior to travel.
- Pre-trip approval from the reporting manager for any trip exceeding 5 nights.
- Currency of expenditure to be converted to INR at the RBI reference rate on
  the date of expense, with the conversion rate noted on the claim.

---

## Section 2: Flight Policy

### 2.1 Cabin Class Rules

| Trip Type     | Allowed by default | Conditionally allowed                         | Requires Finance Head pre-approval |
|---------------|---------------------|------------------------------------------------|-------------------------------------|
| Domestic      | Economy             | Premium Economy (flights > 3 hours, manager pre-approval required) | Business, First |
| International | Economy, Premium Economy | —                                          | Business, First |

**Business and First class are never auto-approved**, regardless of trip type,
seniority, or ticket cost. Any Business or First class booking must have
explicit Finance Head pre-approval recorded (`flight_class_pre_approved: true`
on the claim) or the claim is automatically escalated to Finance Head review
and flagged as a policy violation.

Premium Economy on Domestic sectors is only reimbursable for flights longer
than 3 hours and requires the reporting manager's pre-approval; such claims
are not auto-approved and are routed for manual verification.

### 2.2 Flight Cost Cap

There is **no fixed rupee cap** on flight fares. Employees are expected to
book the lowest reasonable fare in the approved cabin class, ideally at least
14 days in advance for domestic travel and 21 days in advance for
international travel. Finance may query unusually high fares during review,
but the automated agent does not deduct amounts from flight claims on cost
alone -- only cabin-class violations trigger action.

### 2.3 Required Documentation

- E-ticket / boarding pass, or airline invoice showing fare, class, and
  passenger name.
- For Business/First class: the Finance Head pre-approval reference.

---

## Section 3: Hotel Accommodation Policy

Hotel reimbursement is capped **per night**:

| Trip Type     | Cap per night |
|---------------|---------------|
| Domestic      | ₹5,000        |
| International | ₹12,000       |

Amounts claimed above the nightly cap are **not** rejected outright; the
excess over the cap is deducted from the reimbursable amount, and the claim
is marked **Partially Approved** rather than **Rejected**, provided all
required documentation is present.

**Example:** A Domestic hotel claim of ₹6,200 for one night exceeds the
₹5,000 cap by ₹1,200. The agent approves ₹5,000 for the hotel line item and
deducts ₹1,200, citing this section as the policy reference.

Preferred/empanelled hotel chains may be booked above the cap only with prior
written approval from the reporting manager, attached to the claim; the
automated agent cannot verify such approvals and will route these claims to
manual review.

### Required Documentation

- Hotel invoice/bill showing the hotel name, check-in/check-out dates,
  nightly rate, and total amount.
- Without a hotel invoice, the hotel line item cannot be reimbursed and the
  claim is routed to manual review.

---

## Section 4: Meal Allowance (Per Diem)

Meals are reimbursed as a **daily allowance**, not itemized per meal:

| Trip Type     | Cap per day |
|---------------|-------------|
| Domestic      | ₹1,000      |
| International | ₹2,500      |

This is the **per diem** for meals. Employees do not need to submit
itemized restaurant receipts for amounts within the daily cap; a
consolidated claim is sufficient. Amounts claimed above the daily cap have
the excess deducted, and the claim is marked Partially Approved.

**Example:** A Domestic meal claim of ₹2,500 for one day exceeds the
₹1,000 cap by ₹1,500, which is deducted.

Client-entertainment meals (client dinners, business lunches with external
parties) fall outside the standard meal per diem and must be claimed under a
separate "client entertainment" category with the client's name and business
purpose noted; these are treated as an **unknown/other expense category** by
the automated agent and always routed to manual review for Finance
verification.

---

## Section 5: Local Transport / Taxi Policy

Local transport (taxi, cab-hailing apps, airport transfers) is reimbursed as
a **daily cap**:

| Trip Type     | Cap per day |
|---------------|-------------|
| Domestic      | ₹2,000      |
| International | ₹3,000      |

Amounts above the daily cap have the excess deducted and the claim marked
Partially Approved. Ride receipts or app invoices should be retained for
audit purposes but are not individually required as long as the total is
within the daily cap; Finance may request them for claims flagged for manual
review.

Personal travel (e.g., sightseeing unrelated to business purpose) is not
reimbursable under this category.

---

## Section 6: Per Diem Summary

The combined daily per diem (meal + taxi caps) is:

| Trip Type     | Meal/day | Taxi/day | Combined daily per diem |
|---------------|----------|----------|--------------------------|
| Domestic      | ₹1,000   | ₹2,000   | ₹3,000                   |
| International | ₹2,500   | ₹3,000   | ₹5,500                   |

Hotel is capped separately per night as described in Section 3 and is not
part of the per diem.

---

## Section 7: Documentation Requirements

Every claim must have:

1. **`receipt_uploaded: true`** -- a general acknowledgement that proof of
   payment exists for the trip. Without this, no line item can be
   reimbursed and the claim is routed to manual review.
2. **Hotel invoice** for any claim including a hotel line item.
3. **Flight e-ticket/invoice** for any claim including a flight line item.
4. **Invoice number** -- strongly recommended for hotel and flight line
   items; it is the primary key used for duplicate-claim detection. Claims
   without an invoice number can still be processed but are checked against
   prior claims using a lower-confidence heuristic (matching employee, trip
   type, and identical amounts across all categories).
5. **Travel dates and destination** -- recommended so that overlapping-trip
   duplicate detection can run; omitting these does not block approval but
   reduces the agent's ability to catch duplicate submissions.

---

## Section 8: Approval Routing

Regardless of whether the AI agent's assessment is confident, every claim is
routed to a human approval tier based on the **total claimed amount**:

| Total claimed amount        | Approval tier | Approver         |
|------------------------------|---------------|-------------------|
| Below ₹10,000                 | Auto          | None (auto-disbursed) |
| ₹10,000 to below ₹50,000      | Manager       | Direct Manager    |
| ₹50,000 and above             | Finance Head  | Finance Head      |

Any claim containing a Business/First class flight without recorded
pre-approval is escalated to **Finance Head**, overriding the amount-based
tier.

---

## Section 9: Manual Review Triggers

The automated agent forces a claim to **Manual Review** (a human must
examine it before any disbursement, regardless of the amount-based approval
tier) when any of the following are true:

- Required receipts or invoices are missing.
- A duplicate or overlapping claim is suspected.
- The claim contains an expense category not covered by this policy (e.g.
  client entertainment, gifts, unspecified "other" expenses).
- A flight-class violation is present (Business/First without
  pre-approval, or a cabin class not permitted for the trip type).
- The policy retrieval confidence for this scenario is low (i.e. the claim
  describes a situation this policy document does not clearly address).
- The AI agent's own confidence in its assessment is below 60%.

---

## Section 10: Rejection Criteria

A claim is marked **Rejected** (rather than Partially Approved) only when
the entire claimed amount is non-reimbursable under this policy -- for
example, purely personal expenses with no business purpose, or expenses
incurred outside the approved trip dates with no valid business
justification. Partial policy violations (exceeding a cap) result in
**Partially Approved**, not Rejected.

---

## Section 11: Policy Revisions

This policy is reviewed annually by the Finance & Accounts Department.
Employees are notified of changes via the internal HR portal at least 30
days before they take effect. The version in force on the date of travel
governs the claim, not the version in force on the date of filing.
