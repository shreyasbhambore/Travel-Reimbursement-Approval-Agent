"""
FAISS vector store wrapper around LangChain's `FAISS` vectorstore, using
`BAAI/bge-small-en-v1.5` HuggingFace embeddings.

`PolicyVectorStore` is a thin adapter with exactly the surface `retriever.py`
needs (`similarity_search_with_score`), plus build/save/load helpers used by
`ingest.py`. Keeping the LangChain-specific plumbing in this one module means
the rest of the app (`retriever.py`, `tools/policy_lookup.py`) never imports
`langchain_community` or `sentence_transformers` directly.

Score semantics: `similarity_search_with_score` on this class returns
**relevance scores in [0, 1], higher = more relevant** (via LangChain's
`similarity_search_with_relevance_scores`, not raw FAISS L2 distance). This
matches what `PolicyRetriever` / `Settings.RETRIEVAL_MIN_RELEVANCE_SCORE`
expect.
"""
from __future__ import annotations

from pathlib import Path
from typing import List, Tuple

from langchain_core.documents import Document

from logging_config import get_logger

logger = get_logger(__name__)


def _load_embeddings():
    """Import + construct lazily so importing this module doesn't require
    `sentence-transformers`/`torch` unless a vector store is actually built
    or loaded (keeps unit tests, which never touch this module, fast and
    dependency-light)."""
    from langchain_huggingface import HuggingFaceEmbeddings
    from config import get_settings

    settings = get_settings()
    return HuggingFaceEmbeddings(
        model_name=settings.EMBEDDING_MODEL,
        model_kwargs={"device": settings.EMBEDDING_DEVICE},
        encode_kwargs={"normalize_embeddings": True},
    )


class PolicyVectorStore:
    """Wraps a LangChain `FAISS` vectorstore instance."""

    def __init__(self, faiss_store):
        self._store = faiss_store

    # ── Construction ─────────────────────────────────────────────────────

    @classmethod
    def build_from_documents(cls, documents: List[Document]) -> "PolicyVectorStore":
        from langchain_community.vectorstores import FAISS

        embeddings = _load_embeddings()
        logger.info("Building FAISS index from %d document chunks …", len(documents))
        store = FAISS.from_documents(documents, embeddings)
        return cls(store)

    @classmethod
    def load(cls, index_dir: Path) -> "PolicyVectorStore":
        from langchain_community.vectorstores import FAISS

        embeddings = _load_embeddings()
        logger.info("Loading FAISS index from %s …", index_dir)
        store = FAISS.load_local(
            str(index_dir), embeddings, allow_dangerous_deserialization=True
        )
        return cls(store)

    def save(self, index_dir: Path) -> None:
        index_dir.mkdir(parents=True, exist_ok=True)
        self._store.save_local(str(index_dir))
        logger.info("Persisted FAISS index to %s", index_dir)

    # ── Query ────────────────────────────────────────────────────────────

    def similarity_search_with_score(self, query: str, k: int = 4) -> List[Tuple[Document, float]]:
        """Return (Document, relevance_score) pairs, relevance in [0, 1],
        higher = better."""
        return self._store.similarity_search_with_relevance_scores(query, k=k)

    def add_documents(self, documents: List[Document]) -> None:
        self._store.add_documents(documents)
