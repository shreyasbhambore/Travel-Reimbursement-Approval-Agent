"""
Policy retriever: issue a natural-language query against the FAISS index and
return a `PolicyRetrievalResult` that the policy-lookup tool can hand
directly to the LangGraph state.
"""
from __future__ import annotations

from typing import Optional

from config import get_settings
from logging_config import get_logger
from rag.vector_store import PolicyVectorStore
from schemas import PolicyChunk, PolicyRetrievalResult

logger = get_logger(__name__)


class PolicyRetriever:
    """Wraps a loaded `PolicyVectorStore` with query-logic and score
    thresholding.

    Designed to be constructed once (e.g. in `app.py` on startup) and then
    injected into tool instances, rather than re-initialised per request.
    """

    def __init__(self, store: PolicyVectorStore, top_k: Optional[int] = None):
        self._store = store
        settings = get_settings()
        self._top_k = top_k or settings.RETRIEVAL_TOP_K
        self._min_score = settings.RETRIEVAL_MIN_RELEVANCE_SCORE

    def retrieve(self, query: str) -> PolicyRetrievalResult:
        """Return the top-k policy chunks most relevant to *query*.

        *query* should be a short natural-language description of the expense
        or scenario whose policy coverage you need, e.g. "hotel nightly
        reimbursement limit Domestic trip" rather than the raw claim JSON.
        """
        logger.debug("RAG retrieve | query=%r | top_k=%d", query, self._top_k)
        raw = self._store.similarity_search_with_score(query, k=self._top_k)

        chunks = [
            PolicyChunk(
                content=doc.page_content,
                source=doc.metadata.get("source", "travel_policy.md"),
                score=round(score, 4),
            )
            for doc, score in raw
        ]

        top_score = max((c.score for c in chunks), default=0.0)
        low_confidence = top_score < self._min_score

        if low_confidence:
            logger.warning(
                "RAG: top relevance score %.4f below threshold %.4f for query %r; "
                "this will trigger manual_review=True in the agent",
                top_score,
                self._min_score,
                query,
            )
        else:
            logger.debug(
                "RAG: %d chunks retrieved | top_score=%.4f | query=%r",
                len(chunks),
                top_score,
                query,
            )

        return PolicyRetrievalResult(
            chunks=chunks,
            query=query,
            top_score=top_score,
            low_confidence=low_confidence,
        )
