"""RAG subsystem: policy document ingestion, chunking, embedding, and retrieval."""
