"""
Ingestion pipeline: load `data/travel_policy.md`, chunk it, embed the chunks
with `BAAI/bge-small-en-v1.5`, and persist the resulting FAISS index to
`output/faiss_index/`.

`run_ingestion(force=False)` is the single entry point used by `app.py` on
startup:
  - If a persisted index already exists AND the policy document hasn't
    changed since it was built (tracked via a content hash sidecar file),
    the existing index is loaded from disk -- no re-embedding needed.
  - Otherwise (first run, `force=True`, or the policy doc changed), the
    document is re-chunked and re-embedded from scratch and the new index
    is persisted, overwriting the old one.

Run standalone to force a rebuild:
    python -m rag.ingest --force
"""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

from langchain_core.documents import Document

from config import get_settings
from logging_config import configure_logging, get_logger
from rag.vector_store import PolicyVectorStore

logger = get_logger(__name__)

_HASH_SIDECAR_NAME = "source.sha256"


def _hash_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _chunk_markdown(text: str, chunk_size: int, chunk_overlap: int) -> list[str]:
    """Chunk the policy markdown, preferring to split on section headings
    (`## `) first so a chunk never straddles two unrelated policy sections,
    then falling back to a generic recursive splitter for any oversized
    section."""
    from langchain_text_splitters import (
        MarkdownHeaderTextSplitter,
        RecursiveCharacterTextSplitter,
    )

    headers_to_split_on = [("#", "h1"), ("##", "h2"), ("###", "h3")]
    md_splitter = MarkdownHeaderTextSplitter(headers_to_split_on=headers_to_split_on)
    header_docs = md_splitter.split_text(text)

    recursive_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ". ", " ", ""],
    )

    chunks: list[str] = []
    for doc in header_docs:
        heading_prefix = " > ".join(v for v in doc.metadata.values() if v)
        content = f"{heading_prefix}\n{doc.page_content}" if heading_prefix else doc.page_content
        if len(content) <= chunk_size:
            chunks.append(content)
        else:
            chunks.extend(recursive_splitter.split_text(content))
    return chunks


def build_documents_from_policy(policy_path: Path, chunk_size: int, chunk_overlap: int) -> list[Document]:
    if not policy_path.exists():
        raise FileNotFoundError(
            f"Policy document not found at {policy_path}. Run ingestion after ensuring "
            "data/travel_policy.md exists."
        )
    text = policy_path.read_text(encoding="utf-8")
    chunks = _chunk_markdown(text, chunk_size, chunk_overlap)
    logger.info("Chunked %s into %d chunks", policy_path.name, len(chunks))
    return [
        Document(page_content=chunk, metadata={"source": policy_path.name, "chunk_index": i})
        for i, chunk in enumerate(chunks)
    ]


def run_ingestion(force: bool = False) -> PolicyVectorStore:
    """Load an existing FAISS index if it's up to date, otherwise (re)build
    it from `data/travel_policy.md` and persist it. Returns a ready-to-query
    `PolicyVectorStore`."""
    settings = get_settings()
    index_dir = settings.FAISS_INDEX_DIR
    hash_path = index_dir / _HASH_SIDECAR_NAME
    current_hash = _hash_file(settings.POLICY_MD_PATH)

    index_exists = (index_dir / "index.faiss").exists() and (index_dir / "index.pkl").exists()
    hash_matches = index_exists and hash_path.exists() and hash_path.read_text().strip() == current_hash

    if index_exists and hash_matches and not force:
        logger.info("FAISS index up to date at %s; loading from disk.", index_dir)
        return PolicyVectorStore.load(index_dir)

    logger.info(
        "Building FAISS index (force=%s, index_exists=%s, hash_matches=%s) …",
        force,
        index_exists,
        hash_matches,
    )
    documents = build_documents_from_policy(
        settings.POLICY_MD_PATH, settings.CHUNK_SIZE, settings.CHUNK_OVERLAP
    )
    store = PolicyVectorStore.build_from_documents(documents)
    store.save(index_dir)
    hash_path.write_text(current_hash, encoding="utf-8")
    return store


if __name__ == "__main__":
    configure_logging()
    parser = argparse.ArgumentParser(description="Build/refresh the FAISS policy index.")
    parser.add_argument("--force", action="store_true", help="Force a full rebuild even if unchanged.")
    args = parser.parse_args()
    run_ingestion(force=args.force)
    logger.info("Ingestion complete.")
