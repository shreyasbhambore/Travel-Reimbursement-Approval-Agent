"""
Claims ledger: a lightweight, file-backed record of every claim the agent has
finalized, used exclusively by `DuplicateCheckerTool` to detect re-submissions.

Storage is a flat JSON list persisted to `output/claims_ledger.json` (path
configurable via `Settings.CLAIMS_LEDGER_PATH`). This is intentionally simple
for the scope of this assignment; a production deployment would swap this for
a real database (see README "Future Improvements") without touching the tool
interface, since `ClaimsLedger` is the only class that knows about the storage
format.

Thread-safety note: FastAPI with a single Uvicorn worker processes requests
concurrently via asyncio, but each request runs the (synchronous) LangGraph
pipeline in a thread-pool executor, so concurrent writes are possible. A
simple in-process lock guards read-modify-write operations.
"""
from __future__ import annotations

import json
import threading
from dataclasses import asdict, dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import List, Optional


@dataclass
class LedgerEntry:
    claim_id: str
    trip_id: str
    employee_id: str
    invoice_number: Optional[str]
    destination: Optional[str]
    travel_start_date: Optional[str]  # ISO date string
    travel_end_date: Optional[str]
    trip_type: str
    hotel: float
    flight: float
    meal: float
    taxi: float
    evaluated_at: str  # ISO datetime string


class ClaimsLedger:
    """Simple JSON-file-backed store of previously evaluated claims."""

    def __init__(self, path: Path):
        self._path = Path(path)
        self._lock = threading.Lock()
        self._path.parent.mkdir(parents=True, exist_ok=True)
        if not self._path.exists():
            self._write_all([])

    # ── Persistence primitives ───────────────────────────────────────────

    def _read_all(self) -> List[dict]:
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return []

    def _write_all(self, entries: List[dict]) -> None:
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(entries, f, indent=2, default=str)

    def reset(self) -> None:
        """Clear the ledger. Used by tests to guarantee a clean slate."""
        with self._lock:
            self._write_all([])

    # ── Writes ────────────────────────────────────────────────────────────

    def record(self, entry: LedgerEntry) -> None:
        with self._lock:
            entries = self._read_all()
            entries.append(asdict(entry))
            self._write_all(entries)

    def seed(self, entries: List[LedgerEntry]) -> None:
        """Bulk-load entries (used to preload `data/sample_claims.json` at
        startup so the demo has duplicate-detection history out of the box)."""
        with self._lock:
            existing = self._read_all()
            existing_ids = {e["claim_id"] for e in existing}
            new = [asdict(e) for e in entries if e.claim_id not in existing_ids]
            self._write_all(existing + new)

    # ── Reads / duplicate-detection queries ─────────────────────────────

    def find_by_invoice(self, employee_id: str, invoice_number: str) -> Optional[LedgerEntry]:
        for row in self._read_all():
            if row["employee_id"] == employee_id and row.get("invoice_number") == invoice_number:
                return LedgerEntry(**row)
        return None

    def find_overlapping_trip(
        self,
        employee_id: str,
        destination: Optional[str],
        start: Optional[date],
        end: Optional[date],
    ) -> Optional[LedgerEntry]:
        if destination is None or start is None or end is None:
            return None
        for row in self._read_all():
            if row["employee_id"] != employee_id or row.get("destination") != destination:
                continue
            r_start, r_end = row.get("travel_start_date"), row.get("travel_end_date")
            if not r_start or not r_end:
                continue
            try:
                r_start_d = date.fromisoformat(r_start)
                r_end_d = date.fromisoformat(r_end)
            except ValueError:
                continue
            # Overlap test: ranges [start, end] and [r_start_d, r_end_d] intersect.
            if start <= r_end_d and r_start_d <= end:
                return LedgerEntry(**row)
        return None

    def find_amount_heuristic_match(
        self,
        employee_id: str,
        trip_type: str,
        hotel: float,
        flight: float,
        meal: float,
        taxi: float,
        invoice_number: Optional[str] = None,
    ) -> Optional[LedgerEntry]:
        """Low-confidence fallback: same employee/trip_type/amounts.

        If *both* the incoming claim and a candidate ledger row carry a
        (non-null) invoice number and those numbers differ, the candidate is
        skipped -- an explicit, differing invoice number is treated as strong
        evidence that these are two distinct legitimate claims (e.g. the same
        recurring commute route billed identically each week), not a
        resubmission. The heuristic only fires when there isn't enough
        invoice information to already have ruled that out.
        """
        for row in self._read_all():
            row_invoice = row.get("invoice_number")
            if invoice_number and row_invoice and invoice_number != row_invoice:
                continue
            if (
                row["employee_id"] == employee_id
                and row.get("trip_type") == trip_type
                and _close(row.get("hotel", 0), hotel)
                and _close(row.get("flight", 0), flight)
                and _close(row.get("meal", 0), meal)
                and _close(row.get("taxi", 0), taxi)
            ):
                return LedgerEntry(**row)
        return None


def _close(a: float, b: float, tol: float = 0.01) -> bool:
    return abs(float(a) - float(b)) <= tol
