"""
FastAPI application entry point.

Run with:
    uvicorn app:app --reload                 # development
    uvicorn app:app --host 0.0.0.0 --port 8080  # production / Docker

Swagger UI: http://localhost:8000/docs
ReDoc:       http://localhost:8000/redoc
"""
from __future__ import annotations

import time
import uuid
from contextlib import asynccontextmanager
from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.responses import JSONResponse

from agent.graph import build_graph
from agent.nodes import build_nodes
from agent.state import initial_state
from config import get_settings
from ledger import ClaimsLedger
from logging_config import configure_logging, get_logger, log_decision_record
from rag.ingest import run_ingestion
from rag.retriever import PolicyRetriever
from schemas import ClaimDecision, ErrorResponse, HealthStatus, TravelClaim
from tools.approval_checker import ApprovalCheckerTool
from tools.duplicate_checker import DuplicateCheckerTool
from tools.limit_checker import LimitCheckerTool
from tools.policy_lookup import PolicyLookupTool
from tools.receipt_checker import ReceiptCheckerTool
from tools.validator import ValidatorTool

configure_logging()
logger = get_logger(__name__)

# ── Application state container ───────────────────────────────────────────────
# Populated during `lifespan`; accessed via `Depends(get_graph)` etc.
_app_state: dict[str, Any] = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup: build the vector store, wire tools, compile the graph.
    Shutdown: nothing to do (FAISS index and ledger self-flush)."""
    settings = get_settings()
    logger.info("Startup | model=%s | env=%s", settings.GROQ_MODEL, settings.ENVIRONMENT)

    # ── RAG ───────────────────────────────────────────────────────────────
    logger.info("Ingesting / loading FAISS vector store …")
    try:
        vector_store = run_ingestion(force=False)
        retriever = PolicyRetriever(vector_store)
        _app_state["vector_store_ready"] = True
    except Exception as exc:
        logger.error("Failed to load vector store: %s", exc, exc_info=True)
        _app_state["vector_store_ready"] = False
        retriever = None  # API degrades: /health returns 'degraded', /evaluate-claim returns 503

    # ── Tools ─────────────────────────────────────────────────────────────
    ledger = ClaimsLedger(settings.CLAIMS_LEDGER_PATH)
    policy_tool = PolicyLookupTool(retriever) if retriever else None
    receipt_tool = ReceiptCheckerTool()
    limit_tool = LimitCheckerTool()
    approval_tool = ApprovalCheckerTool()
    dup_tool = DuplicateCheckerTool(ledger)
    validator = ValidatorTool()

    # ── Graph ─────────────────────────────────────────────────────────────
    # Guarded: a missing/invalid GROQ_API_KEY (or any other node-wiring
    # failure) must degrade the service to 503 on /evaluate-claim rather than
    # crash the whole application at startup.
    if policy_tool is not None:
        try:
            nodes = build_nodes(
                policy_tool=policy_tool,
                receipt_tool=receipt_tool,
                limit_tool=limit_tool,
                approval_tool=approval_tool,
                dup_tool=dup_tool,
                validator=validator,
                ledger=ledger,
            )
            graph = build_graph(nodes)
            _app_state["graph"] = graph
        except Exception as exc:
            logger.error("Failed to build LangGraph workflow: %s", exc, exc_info=True)
            _app_state["graph"] = None
    else:
        _app_state["graph"] = None

    _app_state["ledger"] = ledger
    logger.info("Startup complete | vector_store_ready=%s", _app_state["vector_store_ready"])

    yield  # ── application runs ──

    logger.info("Shutdown complete.")


def get_graph():
    graph = _app_state.get("graph")
    if graph is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "The evaluation engine is not available. The vector store failed to load on "
                "startup. Check logs and ensure `data/travel_policy.md` is present."
            ),
        )
    return graph


settings = get_settings()

app = FastAPI(
    title=settings.API_TITLE,
    version=settings.API_VERSION,
    description=(
        "Production-grade Travel Reimbursement Approval Agent. "
        "Evaluates employee travel claims against company policy using "
        "LangGraph, RAG (FAISS + BGE embeddings), and Groq's LLM."
    ),
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
)


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get(
    "/health",
    response_model=HealthStatus,
    summary="Health check",
    tags=["Operations"],
)
async def health() -> HealthStatus:
    """Returns service health. Safe to call without authentication; used by
    container orchestration and load-balancer probes."""
    s = get_settings()
    groq_ok = bool(s.GROQ_API_KEY)
    vs_ok = _app_state.get("vector_store_ready", False)
    return HealthStatus(
        status="ok" if (groq_ok and vs_ok) else "degraded",
        version=s.API_VERSION,
        groq_configured=groq_ok,
        vector_store_ready=vs_ok,
        details={
            "groq_model": s.GROQ_MODEL,
            "environment": s.ENVIRONMENT,
            "embedding_model": s.EMBEDDING_MODEL,
        },
    )


@app.post(
    "/evaluate-claim",
    response_model=ClaimDecision,
    status_code=status.HTTP_200_OK,
    summary="Evaluate a travel reimbursement claim",
    tags=["Claims"],
    responses={
        400: {"model": ErrorResponse, "description": "Invalid claim payload"},
        503: {"model": ErrorResponse, "description": "Service temporarily unavailable"},
    },
)
async def evaluate_claim(
    claim: TravelClaim,
    graph=Depends(get_graph),
) -> ClaimDecision:
    """
    Submit a travel reimbursement claim for automated evaluation.

    The agent:
    1. Retrieves relevant company policy via RAG (FAISS + BGE embeddings)
    2. Runs deterministic tool checks: receipt validation, per-category limit
       enforcement, approval routing, duplicate detection
    3. Asks the Groq LLM (openai/gpt-oss-120b by default) for a decision narrative
    4. Validates and corrects the LLM output arithmetically
    5. Returns a structured `ClaimDecision` with the final verdict, deductions,
       reasons, and the approval tier required for disbursement

    **Example minimal payload** (from the assignment brief):
    ```json
    {
      "employee_id": "EMP001",
      "name": "John Doe",
      "trip_type": "Domestic",
      "hotel": 6200,
      "flight": 14000,
      "meal": 900,
      "taxi": 800,
      "receipt_uploaded": true
    }
    ```
    """
    request_id = uuid.uuid4().hex[:8].upper()
    start = time.monotonic()
    logger.info(
        "POST /evaluate-claim | request_id=%s | employee=%s | total=₹%.2f",
        request_id,
        claim.employee_id,
        claim.total_claimed_amount,
    )

    state = initial_state(claim)
    try:
        final_state = graph.invoke(state)
    except Exception as exc:
        logger.error(
            "Graph execution failed | request_id=%s | error=%s", request_id, exc, exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Agent evaluation failed: {exc}",
        ) from exc

    decision: ClaimDecision | None = final_state.get("final_decision")
    if decision is None:
        error_msg = final_state.get("error", "Unknown graph error")
        logger.error(
            "Graph returned no decision | request_id=%s | error=%s", request_id, error_msg
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Agent produced no decision: {error_msg}",
        )

    elapsed = round((time.monotonic() - start) * 1000, 2)
    logger.info(
        "POST /evaluate-claim | request_id=%s | claim_id=%s | decision=%s | "
        "manual_review=%s | total_ms=%.1f",
        request_id,
        decision.claim_id,
        decision.decision.value,
        decision.manual_review,
        elapsed,
    )

    # Write structured audit log entry
    log_decision_record(
        {
            "request_id": request_id,
            "claim_id": decision.claim_id,
            "employee_id": claim.employee_id,
            "trip_type": claim.trip_type.value,
            "total_claimed": claim.total_claimed_amount,
            "decision": decision.decision.value,
            "approved_amount": decision.approved_amount,
            "deduction": decision.deduction,
            "manual_review": decision.manual_review,
            "approval_level": decision.approval_level.value,
            "duplicate_suspected": decision.duplicate_suspected,
            "confidence": decision.confidence,
            "model": decision.model_used,
            "total_ms": elapsed,
        }
    )

    return decision
